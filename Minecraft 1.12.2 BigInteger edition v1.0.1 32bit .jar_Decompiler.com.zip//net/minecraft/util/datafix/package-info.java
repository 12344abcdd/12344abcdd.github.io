package net.minecraft.util.datafix;

import javax.annotation.ParametersAreNonnullByDefault;
import mcp.MethodsReturnNonnullByDefault;

// $FF: synthetic class
@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
interface package-info {
}
