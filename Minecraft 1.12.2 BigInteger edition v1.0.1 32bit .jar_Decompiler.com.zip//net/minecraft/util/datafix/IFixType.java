package net.minecraft.util.datafix;

public interface IFixType {
}
