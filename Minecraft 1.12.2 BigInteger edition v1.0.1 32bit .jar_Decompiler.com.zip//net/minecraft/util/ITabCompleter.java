package net.minecraft.util;

public interface ITabCompleter {
   void setCompletions(String... var1);
}
