package net.minecraft.util;

import io.netty.buffer.ByteBuf;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;
import javax.annotation.Nullable;
import net.minecraft.network.PacketBuffer;
import org.apache.logging.log4j.Logger;

public class Util {
   public static Util.EnumOS getOSType() {
      String s = System.getProperty("os.name").toLowerCase(Locale.ROOT);
      if (s.contains("win")) {
         return Util.EnumOS.WINDOWS;
      } else if (s.contains("mac")) {
         return Util.EnumOS.OSX;
      } else if (s.contains("solaris")) {
         return Util.EnumOS.SOLARIS;
      } else if (s.contains("sunos")) {
         return Util.EnumOS.SOLARIS;
      } else if (s.contains("linux")) {
         return Util.EnumOS.LINUX;
      } else {
         return s.contains("unix") ? Util.EnumOS.LINUX : Util.EnumOS.UNKNOWN;
      }
   }

   public static BigInteger readBigInteger(ByteBuf buf) {
      byte[] b = new byte[buf.readInt()];
      buf.readBytes(b);
      return new BigInteger(b);
   }

   public static void writeBigInteger(ByteBuf buf, BigInteger i) {
      byte[] b = i.toByteArray();
      buf.writeInt(b.length);
      buf.writeBytes(b);
   }

   public static BigDecimal readBigDecimal(PacketBuffer buf) {
      return new BigDecimal(readBigInteger(buf), buf.readInt());
   }

   public static void writeBigDecimal(PacketBuffer buf, BigDecimal val) {
      writeBigInteger(buf, val.unscaledValue());
      buf.writeInt(val.scale());
   }

   @Nullable
   public static <V> V runTask(FutureTask<V> task, Logger logger) {
      try {
         task.run();
         return task.get();
      } catch (ExecutionException var3) {
         logger.fatal("Error executing task", var3);
      } catch (InterruptedException var4) {
         logger.fatal("Error executing task", var4);
      }

      return null;
   }

   public static <T> T getLastElement(List<T> list) {
      return list.get(list.size() - 1);
   }

   public static enum EnumOS {
      LINUX,
      SOLARIS,
      WINDOWS,
      OSX,
      UNKNOWN;
   }
}
