package net.minecraft.util;

public interface ITickable {
   void update();
}
