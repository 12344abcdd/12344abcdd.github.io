package net.minecraft.util;

public enum EnumBlockRenderType {
   INVISIBLE,
   LIQUID,
   ENTITYBLOCK_ANIMATED,
   MODEL;
}
