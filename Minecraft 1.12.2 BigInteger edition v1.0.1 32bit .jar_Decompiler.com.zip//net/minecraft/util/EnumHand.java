package net.minecraft.util;

public enum EnumHand {
   MAIN_HAND,
   OFF_HAND;
}
