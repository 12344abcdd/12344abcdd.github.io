package net.minecraft.util;

public class StructureBoundingBoxBigInteger {
}
