package net.minecraft.util.math;

import com.google.common.annotations.VisibleForTesting;
import java.math.BigDecimal;
import java.math.BigInteger;
import javax.annotation.Nullable;
import net.minecraft.util.EnumFacing;

public class BigDecimalAABB {
   public final BigDecimal minX;
   public final double minY;
   public final BigDecimal minZ;
   public final BigDecimal maxX;
   public final double maxY;
   public final BigDecimal maxZ;

   public BigDecimalAABB(double x1, double y1, double z1, double x2, double y2, double z2) {
      this.minX = new BigDecimal(Math.min(x1, x2));
      this.minY = Math.min(y1, y2);
      this.minZ = new BigDecimal(Math.min(z1, z2));
      this.maxX = new BigDecimal(Math.max(x1, x2));
      this.maxY = Math.max(y1, y2);
      this.maxZ = new BigDecimal(Math.max(z1, z2));
   }

   public BigDecimalAABB(BigDecimal x1, double y1, BigDecimal z1, BigDecimal x2, double y2, BigDecimal z2) {
      this.minX = x1.min(x2);
      this.minY = Math.min(y1, y2);
      this.minZ = z1.min(z2);
      this.maxX = x2.max(x1);
      this.maxY = Math.max(y2, y1);
      this.maxZ = z2.max(z1);
   }

   public BigDecimalAABB(BlockPos pos) {
      this(new BigDecimal(pos.getX()), (double)pos.getY(), new BigDecimal(pos.getZ()), new BigDecimal(pos.getX().add(BigInteger.ONE)), (double)(pos.getY() + 1), new BigDecimal(pos.getZ().add(BigInteger.ONE)));
   }

   public BigDecimalAABB(BlockPos pos1, BlockPos pos2) {
      this(pos1.getX().doubleValue(), (double)pos1.getY(), pos1.getZ().doubleValue(), pos2.getX().doubleValue(), (double)pos2.getY(), pos2.getZ().doubleValue());
   }

   public BigDecimalAABB(Vec3d min, Vec3d max) {
      this(min.x, min.y, min.z, max.x, max.y, max.z);
   }

   public BigDecimalAABB setMaxY(double y2) {
      return new BigDecimalAABB(this.minX, this.minY, this.minZ, this.maxX, y2, this.maxZ);
   }

   public boolean equals(Object p_equals_1_) {
      if (this == p_equals_1_) {
         return true;
      } else if (!(p_equals_1_ instanceof BigDecimalAABB)) {
         return false;
      } else {
         BigDecimalAABB axisalignedbb = (BigDecimalAABB)p_equals_1_;
         if (axisalignedbb.minX.compareTo(this.minX) != 0) {
            return false;
         } else if (Double.compare(axisalignedbb.minY, this.minY) != 0) {
            return false;
         } else if (axisalignedbb.minZ.compareTo(this.minZ) != 0) {
            return false;
         } else if (axisalignedbb.maxX.compareTo(this.maxX) != 0) {
            return false;
         } else if (Double.compare(axisalignedbb.maxY, this.maxY) != 0) {
            return false;
         } else {
            return axisalignedbb.maxZ.compareTo(this.maxZ) == 0;
         }
      }
   }

   public int hashCode() {
      long i = Double.doubleToLongBits(this.minX.doubleValue());
      int j = (int)(i ^ i >>> 32);
      i = Double.doubleToLongBits(this.minY);
      j = 31 * j + (int)(i ^ i >>> 32);
      i = Double.doubleToLongBits(this.minZ.doubleValue());
      j = 31 * j + (int)(i ^ i >>> 32);
      i = Double.doubleToLongBits(this.maxX.doubleValue());
      j = 31 * j + (int)(i ^ i >>> 32);
      i = Double.doubleToLongBits(this.maxY);
      j = 31 * j + (int)(i ^ i >>> 32);
      i = Double.doubleToLongBits(this.maxZ.doubleValue());
      j = 31 * j + (int)(i ^ i >>> 32);
      return j;
   }

   public BigDecimalAABB contract(double x, double y, double z) {
      return this.contract(new BigDecimal(x), y, new BigDecimal(z));
   }

   public BigDecimalAABB contract(BigDecimal x, double y, BigDecimal z) {
      BigDecimal d0 = this.minX;
      double d1 = this.minY;
      BigDecimal d2 = this.minZ;
      BigDecimal d3 = this.maxX;
      double d4 = this.maxY;
      BigDecimal d5 = this.maxZ;
      if (x.signum() == -1) {
         d0 = d0.subtract(x);
      } else if (x.signum() == 1) {
         d3 = d3.subtract(x);
      }

      if (y < 0.0D) {
         d1 -= y;
      } else if (y > 0.0D) {
         d4 -= y;
      }

      if (z.signum() == -1) {
         d2 = d2.subtract(z);
      } else if (z.signum() == 1) {
         d5 = d5.subtract(z);
      }

      return new BigDecimalAABB(d0, d1, d2, d3, d4, d5);
   }

   public BigDecimalAABB expand(double x, double y, double z) {
      return this.expand(new BigDecimal(x), y, new BigDecimal(z));
   }

   public BigDecimalAABB expand(BigDecimal x, double y, BigDecimal z) {
      BigDecimal d0 = this.minX;
      double d1 = this.minY;
      BigDecimal d2 = this.minZ;
      BigDecimal d3 = this.maxX;
      double d4 = this.maxY;
      BigDecimal d5 = this.maxZ;
      if (x.signum() == -1) {
         d0 = d0.add(x);
      } else if (x.signum() == 1) {
         d3 = d3.add(x);
      }

      if (y < 0.0D) {
         d1 += y;
      } else if (y > 0.0D) {
         d4 += y;
      }

      if (z.signum() == -1) {
         d2 = d2.add(z);
      } else if (z.signum() == 1) {
         d5 = d5.add(z);
      }

      return new BigDecimalAABB(d0, d1, d2, d3, d4, d5);
   }

   public BigDecimalAABB grow(double x, double y, double z) {
      return this.grow(new BigDecimal(x), y, new BigDecimal(z));
   }

   public BigDecimalAABB grow(BigDecimal x, double y, BigDecimal z) {
      BigDecimal d0 = this.minX.subtract(x);
      double d1 = this.minY - y;
      BigDecimal d2 = this.minZ.subtract(z);
      BigDecimal d3 = this.maxX.add(x);
      double d4 = this.maxY + y;
      BigDecimal d5 = this.maxZ.add(z);
      return new BigDecimalAABB(d0, d1, d2, d3, d4, d5);
   }

   public BigDecimalAABB grow(double value) {
      return this.grow(value, value, value);
   }

   public BigDecimalAABB intersect(BigDecimalAABB p_191500_1_) {
      BigDecimal d0 = this.minX.max(p_191500_1_.minX);
      double d1 = Math.max(this.minY, p_191500_1_.minY);
      BigDecimal d2 = this.minZ.max(p_191500_1_.minZ);
      BigDecimal d3 = this.maxX.min(p_191500_1_.maxX);
      double d4 = Math.min(this.maxY, p_191500_1_.maxY);
      BigDecimal d5 = this.maxZ.min(p_191500_1_.maxZ);
      return new BigDecimalAABB(d0, d1, d2, d3, d4, d5);
   }

   public BigDecimalAABB union(BigDecimalAABB other) {
      BigDecimal d0 = this.minX.min(other.minX);
      double d1 = Math.min(this.minY, other.minY);
      BigDecimal d2 = this.minZ.min(other.minZ);
      BigDecimal d3 = this.maxX.max(other.maxX);
      double d4 = Math.max(this.maxY, other.maxY);
      BigDecimal d5 = this.maxZ.max(other.maxZ);
      return new BigDecimalAABB(d0, d1, d2, d3, d4, d5);
   }

   public BigDecimalAABB offset(double x, double y, double z) {
      return this.offset(new BigDecimal(x), y, new BigDecimal(z));
   }

   public BigDecimalAABB offset(BigDecimal x, double y, BigDecimal z) {
      return new BigDecimalAABB(this.minX.add(x), this.minY + y, this.minZ.add(z), this.maxX.add(x), this.maxY + y, this.maxZ.add(z));
   }

   public BigDecimalAABB offset(BlockPos pos) {
      return new BigDecimalAABB(this.minX.add(new BigDecimal(pos.getX())), this.minY + (double)pos.getY(), this.minZ.add(new BigDecimal(pos.getZ())), this.maxX.add(new BigDecimal(pos.getX())), this.maxY + (double)pos.getY(), this.maxZ.add(new BigDecimal(pos.getZ())));
   }

   public BigDecimalAABB offset(Vec3d p_191194_1_) {
      return this.offset(p_191194_1_.x, p_191194_1_.y, p_191194_1_.z);
   }

   public double calculateXOffset(BigDecimalAABB other, double offsetX) {
      if (other.maxY > this.minY && other.minY < this.maxY && other.maxZ.compareTo(this.minZ) > 0 && other.minZ.compareTo(this.maxZ) < 0) {
         double d0;
         if (offsetX > 0.0D && other.maxX.compareTo(this.minX) <= 0) {
            d0 = this.minX.subtract(other.maxX).doubleValue();
            if (d0 < offsetX) {
               offsetX = d0;
            }
         } else if (offsetX < 0.0D && other.minX.compareTo(this.maxX) >= 0) {
            d0 = this.maxX.subtract(other.minX).doubleValue();
            if (d0 > offsetX) {
               offsetX = d0;
            }
         }

         return offsetX;
      } else {
         return offsetX;
      }
   }

   public BigDecimal calculateXOffset(BigDecimalAABB other, BigDecimal offsetX) {
      if (other.maxY > this.minY && other.minY < this.maxY && other.maxZ.compareTo(this.minZ) > 0 && other.minZ.compareTo(this.maxZ) < 0) {
         BigDecimal d0;
         if (offsetX.signum() == 1 && other.maxX.compareTo(this.minX) <= 0) {
            d0 = this.minX.subtract(other.maxX);
            if (d0.compareTo(offsetX) < 0) {
               offsetX = d0;
            }
         } else if (offsetX.signum() == -1 && other.minX.compareTo(this.maxX) >= 0) {
            d0 = this.maxX.subtract(other.minX);
            if (d0.compareTo(offsetX) > 0) {
               offsetX = d0;
            }
         }

         return offsetX;
      } else {
         return offsetX;
      }
   }

   public double calculateYOffset(BigDecimalAABB other, double offsetY) {
      if (other.maxX.compareTo(this.minX) > 0 && other.minX.compareTo(this.maxX) < 0 && other.maxZ.compareTo(this.minZ) > 0 && other.minZ.compareTo(this.maxZ) < 0) {
         double d0;
         if (offsetY > 0.0D && other.maxY <= this.minY) {
            d0 = this.minY - other.maxY;
            if (d0 < offsetY) {
               offsetY = d0;
            }
         } else if (offsetY < 0.0D && other.minY >= this.maxY) {
            d0 = this.maxY - other.minY;
            if (d0 > offsetY) {
               offsetY = d0;
            }
         }

         return offsetY;
      } else {
         return offsetY;
      }
   }

   public double calculateZOffset(BigDecimalAABB other, double offsetZ) {
      if (other.maxX.compareTo(this.minX) > 0 && other.minX.compareTo(this.maxX) < 0 && other.maxY > this.minY && other.minY < this.maxY) {
         double d0;
         if (offsetZ > 0.0D && other.maxZ.compareTo(this.minZ) <= 0) {
            d0 = this.minZ.subtract(other.maxZ).doubleValue();
            if (d0 < offsetZ) {
               offsetZ = d0;
            }
         } else if (offsetZ < 0.0D && other.minZ.compareTo(this.maxZ) >= 0) {
            d0 = this.maxZ.subtract(other.minZ).doubleValue();
            if (d0 > offsetZ) {
               offsetZ = d0;
            }
         }

         return offsetZ;
      } else {
         return offsetZ;
      }
   }

   public BigDecimal calculateZOffset(BigDecimalAABB other, BigDecimal offsetZ) {
      if (other.maxX.compareTo(this.minX) > 0 && other.minX.compareTo(this.maxX) < 0 && other.maxY > this.minY && other.minY < this.maxY) {
         BigDecimal d0;
         if (offsetZ.signum() == 1 && other.maxZ.compareTo(this.minZ) <= 0) {
            d0 = this.minZ.subtract(other.maxZ);
            if (d0.compareTo(offsetZ) < 0) {
               offsetZ = d0;
            }
         } else if (offsetZ.signum() == -1 && other.minZ.compareTo(this.maxZ) >= 0) {
            d0 = this.maxZ.subtract(other.minZ);
            if (d0.compareTo(offsetZ) > 0) {
               offsetZ = d0;
            }
         }

         return offsetZ;
      } else {
         return offsetZ;
      }
   }

   public boolean intersects(BigDecimalAABB other) {
      return this.intersects(other.minX, other.minY, other.minZ, other.maxX, other.maxY, other.maxZ);
   }

   public boolean intersects(double x1, double y1, double z1, double x2, double y2, double z2) {
      return this.intersects(new BigDecimal(x1), y1, new BigDecimal(z1), new BigDecimal(x2), y2, new BigDecimal(z2));
   }

   public boolean intersects(BigDecimal x1, double y1, BigDecimal z1, BigDecimal x2, double y2, BigDecimal z2) {
      return this.minX.compareTo(x2) < 0 && this.maxX.compareTo(x1) > 0 && this.minY < y2 && this.maxY > y1 && this.minZ.compareTo(z2) < 0 && this.maxZ.compareTo(z1) > 0;
   }

   public boolean intersects(Vec3d min, Vec3d max) {
      return this.intersects(Math.min(min.x, max.x), Math.min(min.y, max.y), Math.min(min.z, max.z), Math.max(min.x, max.x), Math.max(min.y, max.y), Math.max(min.z, max.z));
   }

   public boolean contains(Vec3d vec) {
      BigDecimal x = new BigDecimal(vec.x);
      BigDecimal z = new BigDecimal(vec.z);
      if (x.compareTo(this.minX) > 0 && x.compareTo(this.maxX) < 0) {
         if (vec.y > this.minY && vec.y < this.maxY) {
            return z.compareTo(this.minZ) > 0 && z.compareTo(this.maxZ) < 0;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public boolean contains(Vec3Decimal vec) {
      BigDecimal x = vec.x;
      BigDecimal z = vec.z;
      if (x.compareTo(this.minX) > 0 && x.compareTo(this.maxX) < 0) {
         if (vec.y > this.minY && vec.y < this.maxY) {
            return z.compareTo(this.minZ) > 0 && z.compareTo(this.maxZ) < 0;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public double getAverageEdgeLength() {
      double d0 = this.maxX.subtract(this.minX).doubleValue();
      double d1 = this.maxY - this.minY;
      double d2 = this.maxZ.subtract(this.minZ).doubleValue();
      return (d0 + d1 + d2) / 3.0D;
   }

   public BigDecimalAABB shrink(double value) {
      return this.grow(-value);
   }

   @Nullable
   public RayTraceResult calculateIntercept(Vec3Decimal vecA, Vec3Decimal vecB) {
      Vec3Decimal vec3d = this.collideWithXPlane(this.minX, vecA, vecB);
      EnumFacing enumfacing = EnumFacing.WEST;
      Vec3Decimal vec3d1 = this.collideWithXPlane(this.maxX, vecA, vecB);
      if (vec3d1 != null && this.isClosest(vecA, vec3d, vec3d1)) {
         vec3d = vec3d1;
         enumfacing = EnumFacing.EAST;
      }

      vec3d1 = this.collideWithYPlane(this.minY, vecA, vecB);
      if (vec3d1 != null && this.isClosest(vecA, vec3d, vec3d1)) {
         vec3d = vec3d1;
         enumfacing = EnumFacing.DOWN;
      }

      vec3d1 = this.collideWithYPlane(this.maxY, vecA, vecB);
      if (vec3d1 != null && this.isClosest(vecA, vec3d, vec3d1)) {
         vec3d = vec3d1;
         enumfacing = EnumFacing.UP;
      }

      vec3d1 = this.collideWithZPlane(this.minZ, vecA, vecB);
      if (vec3d1 != null && this.isClosest(vecA, vec3d, vec3d1)) {
         vec3d = vec3d1;
         enumfacing = EnumFacing.NORTH;
      }

      vec3d1 = this.collideWithZPlane(this.maxZ, vecA, vecB);
      if (vec3d1 != null && this.isClosest(vecA, vec3d, vec3d1)) {
         vec3d = vec3d1;
         enumfacing = EnumFacing.SOUTH;
      }

      return vec3d == null ? null : new RayTraceResult(vec3d, enumfacing);
   }

   @VisibleForTesting
   boolean isClosest(Vec3Decimal p_186661_1_, @Nullable Vec3Decimal p_186661_2_, Vec3Decimal p_186661_3_) {
      return p_186661_2_ == null || p_186661_1_.squareDistanceTo(p_186661_3_) < p_186661_1_.squareDistanceTo(p_186661_2_);
   }

   @Nullable
   @VisibleForTesting
   Vec3Decimal collideWithXPlane(BigDecimal p_186671_1_, Vec3Decimal p_186671_3_, Vec3Decimal p_186671_4_) {
      Vec3Decimal vec3d = p_186671_3_.getIntermediateWithXValue(p_186671_4_, p_186671_1_);
      return vec3d != null && this.intersectsWithYZ(vec3d) ? vec3d : null;
   }

   @Nullable
   @VisibleForTesting
   Vec3Decimal collideWithYPlane(double p_186663_1_, Vec3Decimal p_186663_3_, Vec3Decimal p_186663_4_) {
      Vec3Decimal vec3d = p_186663_3_.getIntermediateWithYValue(p_186663_4_, p_186663_1_);
      return vec3d != null && this.intersectsWithXZ(vec3d) ? vec3d : null;
   }

   @Nullable
   @VisibleForTesting
   Vec3Decimal collideWithZPlane(BigDecimal p_186665_1_, Vec3Decimal p_186665_3_, Vec3Decimal p_186665_4_) {
      Vec3Decimal vec3d = p_186665_3_.getIntermediateWithZValue(p_186665_4_, p_186665_1_);
      return vec3d != null && this.intersectsWithXY(vec3d) ? vec3d : null;
   }

   @VisibleForTesting
   public boolean intersectsWithYZ(Vec3d vec) {
      BigDecimal z = new BigDecimal(vec.z);
      return vec.y >= this.minY && vec.y <= this.maxY && z.compareTo(this.minZ) >= 0 && z.compareTo(this.maxZ) <= 0;
   }

   @VisibleForTesting
   public boolean intersectsWithXZ(Vec3d vec) {
      BigDecimal x = new BigDecimal(vec.x);
      BigDecimal z = new BigDecimal(vec.z);
      return x.compareTo(this.minX) >= 0 && x.compareTo(this.maxX) <= 0 && z.compareTo(this.minZ) >= 0 && z.compareTo(this.maxZ) <= 0;
   }

   @VisibleForTesting
   public boolean intersectsWithXY(Vec3d vec) {
      BigDecimal x = new BigDecimal(vec.x);
      return x.compareTo(this.minX) >= 0 && x.compareTo(this.maxX) <= 0 && vec.y >= this.minY && vec.y <= this.maxY;
   }

   @VisibleForTesting
   public boolean intersectsWithYZ(Vec3Decimal vec) {
      return vec.y >= this.minY && vec.y <= this.maxY && vec.z.compareTo(this.minZ) >= 0 && vec.z.compareTo(this.maxZ) <= 0;
   }

   @VisibleForTesting
   public boolean intersectsWithXZ(Vec3Decimal vec) {
      return vec.x.compareTo(this.minX) >= 0 && vec.x.compareTo(this.maxX) <= 0 && vec.z.compareTo(this.minZ) >= 0 && vec.z.compareTo(this.maxZ) <= 0;
   }

   @VisibleForTesting
   public boolean intersectsWithXY(Vec3Decimal vec) {
      return vec.x.compareTo(this.minX) >= 0 && vec.x.compareTo(this.maxX) <= 0 && vec.y >= this.minY && vec.y <= this.maxY;
   }

   public String toString() {
      return "box[" + this.minX + ", " + this.minY + ", " + this.minZ + " -> " + this.maxX + ", " + this.maxY + ", " + this.maxZ + "]";
   }

   public boolean hasNaN() {
      return Double.isNaN(this.minY) || Double.isNaN(this.maxY);
   }

   public Vec3Decimal getCenter() {
      return new Vec3Decimal(this.minX.add(this.maxX.subtract(this.minX).divide(new BigDecimal(2.0D), Vec3Decimal.CONTEXT)), this.minY + (this.maxY - this.minY) * 0.5D, this.minZ.add(this.maxZ.subtract(this.minZ).divide(new BigDecimal(2.0D), Vec3Decimal.CONTEXT)));
   }

   public AxisAlignedBB toAxisAlignedBB() {
      return new AxisAlignedBB(this.minX.doubleValue(), this.minY, this.minZ.doubleValue(), this.maxX.doubleValue(), this.maxY, this.maxZ.doubleValue());
   }
}
