package net.minecraft.util.math;

import com.google.common.collect.AbstractIterator;
import com.google.common.collect.Lists;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Iterator;
import java.util.List;
import javax.annotation.concurrent.Immutable;
import net.minecraft.entity.Entity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Rotation;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Immutable
public class BlockPos extends Vec3i {
   private static final Logger LOGGER = LogManager.getLogger();
   public static final BlockPos ORIGIN = new BlockPos(0, 0, 0);
   private static final int NUM_X_BITS = 1 + MathHelper.log2(MathHelper.smallestEncompassingPowerOfTwo(30000000));
   private static final int NUM_Z_BITS;
   private static final int NUM_Y_BITS;
   private static final int Y_SHIFT;
   private static final int X_SHIFT;
   private static final long X_MASK;
   private static final long Y_MASK;
   private static final long Z_MASK;

   public BlockPos(int x, int y, int z) {
      super(x, y, z);
   }

   public BlockPos(double x, double y, double z) {
      super(x, y, z);
   }

   public BlockPos(BigDecimal x, double y, BigDecimal z) {
      super(x, y, z);
   }

   public BlockPos(Entity source) {
      this(source.posX, source.posY, source.posZ);
   }

   public BlockPos(Vec3d vec) {
      this(vec.x, vec.y, vec.z);
   }

   public BlockPos(Vec3Decimal vec) {
      this(vec.x, vec.y, vec.z);
   }

   public BlockPos(Vec3i source) {
      this(source.getX(), source.getY(), source.getZ());
   }

   public BlockPos(BigInteger x, int y, BigInteger z) {
      super(x, y, z);
   }

   public BlockPos add(double x, double y, double z) {
      return x == 0.0D && y == 0.0D && z == 0.0D ? this : this.add(new BigDecimal(x), y, new BigDecimal(z));
   }

   public BlockPos add(BigDecimal x, double y, BigDecimal z) {
      return x.signum() == 0 && y == 0.0D && z.signum() == 0 ? this : new BlockPos((new BigDecimal(this.getX())).add(x), (double)this.getY() + y, (new BigDecimal(this.getZ())).add(z));
   }

   public BlockPos add(int x, int y, int z) {
      return x == 0 && y == 0 && z == 0 ? this : this.add(BigInteger.valueOf((long)x), y, BigInteger.valueOf((long)z));
   }

   public BlockPos add(BigInteger x, int y, BigInteger z) {
      return x.signum() == 0 && y == 0 && z.signum() == 0 ? this : new BlockPos(this.getX().add(x), this.getY() + y, this.getZ().add(z));
   }

   public BlockPos add(Vec3i vec) {
      return this.add(vec.getX(), vec.getY(), vec.getZ());
   }

   public BlockPos subtract(Vec3i vec) {
      return this.add(vec.getX().negate(), -vec.getY(), vec.getZ().negate());
   }

   public BlockPos up() {
      return this.up(1);
   }

   public BlockPos up(int n) {
      return this.offset(EnumFacing.UP, n);
   }

   public BlockPos down() {
      return this.down(1);
   }

   public BlockPos down(int n) {
      return this.offset(EnumFacing.DOWN, n);
   }

   public BlockPos north() {
      return this.north(1);
   }

   public BlockPos north(int n) {
      return this.offset(EnumFacing.NORTH, n);
   }

   public BlockPos south() {
      return this.south(1);
   }

   public BlockPos south(int n) {
      return this.offset(EnumFacing.SOUTH, n);
   }

   public BlockPos west() {
      return this.west(1);
   }

   public BlockPos west(int n) {
      return this.offset(EnumFacing.WEST, n);
   }

   public BlockPos east() {
      return this.east(1);
   }

   public BlockPos east(int n) {
      return this.offset(EnumFacing.EAST, n);
   }

   public BlockPos offset(EnumFacing facing) {
      return this.offset(facing, 1);
   }

   public BlockPos offset(EnumFacing facing, int n) {
      return n == 0 ? this : this.add(facing.getFrontOffsetX() * n, facing.getFrontOffsetY() * n, facing.getFrontOffsetZ() * n);
   }

   public BlockPos rotate(Rotation rotationIn) {
      switch(rotationIn) {
      case NONE:
      default:
         return this;
      case CLOCKWISE_90:
         return new BlockPos(this.getZ().negate(), this.getY(), this.getX());
      case CLOCKWISE_180:
         return new BlockPos(this.getX().negate(), this.getY(), this.getZ().negate());
      case COUNTERCLOCKWISE_90:
         return new BlockPos(this.getZ(), this.getY(), this.getX().negate());
      }
   }

   public BlockPos crossProduct(Vec3i vec) {
      BigInteger y = BigInteger.valueOf((long)this.getY());
      return new BlockPos(y.multiply(vec.getZ()).subtract(this.getZ().multiply(y)), this.getZ().multiply(vec.getX()).subtract(this.getX().multiply(vec.getZ())).intValueExact(), this.getX().multiply(BigInteger.valueOf((long)vec.getY())).subtract(y.multiply(vec.getX())));
   }

   public long generateSeed() {
      return ((long)this.getX().intValue() & X_MASK) << X_SHIFT | ((long)this.getY() & Y_MASK) << Y_SHIFT | ((long)this.getZ().intValue() & Z_MASK) << 0;
   }

   public static Iterable<BlockPos> getAllInBox(BlockPos from, BlockPos to) {
      return getAllInBox(from.getX().min(to.getX()), Math.min(from.getY(), to.getY()), from.getZ().min(to.getZ()), from.getX().max(to.getX()), Math.max(from.getY(), to.getY()), from.getZ().max(to.getZ()));
   }

   public static Iterable<BlockPos> getAllInBox(final BigInteger p_191532_0_, final int p_191532_1_, final BigInteger p_191532_2_, final BigInteger p_191532_3_, final int p_191532_4_, final BigInteger p_191532_5_) {
      return new Iterable<BlockPos>() {
         public Iterator<BlockPos> iterator() {
            return new AbstractIterator<BlockPos>() {
               private boolean first = true;
               private BigInteger lastPosX;
               private int lastPosY;
               private BigInteger lastPosZ;

               protected BlockPos computeNext() {
                  if (this.first) {
                     this.first = false;
                     this.lastPosX = p_191532_0_;
                     this.lastPosY = p_191532_1_;
                     this.lastPosZ = p_191532_2_;
                     return new BlockPos(p_191532_0_, p_191532_1_, p_191532_2_);
                  } else if (this.lastPosX.equals(p_191532_3_) && this.lastPosY == p_191532_4_ && this.lastPosZ.equals(p_191532_5_)) {
                     return (BlockPos)this.endOfData();
                  } else {
                     if (this.lastPosX.compareTo(p_191532_3_) < 0) {
                        this.lastPosX = this.lastPosX.add(BigInteger.ONE);
                     } else if (this.lastPosY < p_191532_4_) {
                        this.lastPosX = p_191532_0_;
                        ++this.lastPosY;
                     } else if (this.lastPosZ.compareTo(p_191532_5_) < 0) {
                        this.lastPosX = p_191532_0_;
                        this.lastPosY = p_191532_1_;
                        this.lastPosZ = this.lastPosZ.add(BigInteger.ONE);
                     }

                     return new BlockPos(this.lastPosX, this.lastPosY, this.lastPosZ);
                  }
               }
            };
         }
      };
   }

   public BlockPos toImmutable() {
      return this;
   }

   public static Iterable<BlockPos.MutableBlockPos> getAllInBoxMutable(BlockPos from, BlockPos to) {
      return mutablesBetween(from.getX().min(to.getX()), Math.min(from.getY(), to.getY()), from.getZ().min(to.getZ()), from.getX().max(to.getX()), Math.max(from.getY(), to.getY()), from.getZ().max(to.getZ()));
   }

   public static Iterable<BlockPos.MutableBlockPos> mutablesBetween(final BigInteger p_191531_0_, final int p_191531_1_, final BigInteger p_191531_2_, final BigInteger p_191531_3_, final int p_191531_4_, final BigInteger p_191531_5_) {
      return new Iterable<BlockPos.MutableBlockPos>() {
         public Iterator<BlockPos.MutableBlockPos> iterator() {
            return new AbstractIterator<BlockPos.MutableBlockPos>() {
               private BlockPos.MutableBlockPos pos;

               protected BlockPos.MutableBlockPos computeNext() {
                  if (this.pos == null) {
                     this.pos = new BlockPos.MutableBlockPos(p_191531_0_, p_191531_1_, p_191531_2_);
                     return this.pos;
                  } else if (this.pos.x.equals(p_191531_3_) && this.pos.y == p_191531_4_ && this.pos.z.equals(p_191531_5_)) {
                     return (BlockPos.MutableBlockPos)this.endOfData();
                  } else {
                     if (this.pos.x.compareTo(p_191531_3_) < 0) {
                        this.pos.x = this.pos.x.add(BigInteger.ONE);
                     } else if (this.pos.y < p_191531_4_) {
                        this.pos.x = p_191531_0_;
                        ++this.pos.y;
                     } else if (this.pos.z.compareTo(p_191531_5_) < 0) {
                        this.pos.x = p_191531_0_;
                        this.pos.y = p_191531_1_;
                        this.pos.z = this.pos.z.add(BigInteger.ONE);
                     }

                     return this.pos;
                  }
               }
            };
         }
      };
   }

   static {
      NUM_Z_BITS = NUM_X_BITS;
      NUM_Y_BITS = 64 - NUM_X_BITS - NUM_Z_BITS;
      Y_SHIFT = 0 + NUM_Z_BITS;
      X_SHIFT = Y_SHIFT + NUM_Y_BITS;
      X_MASK = (1L << NUM_X_BITS) - 1L;
      Y_MASK = (1L << NUM_Y_BITS) - 1L;
      Z_MASK = (1L << NUM_Z_BITS) - 1L;
   }

   public static final class PooledMutableBlockPos extends BlockPos.MutableBlockPos {
      private boolean released;
      private static final List<BlockPos.PooledMutableBlockPos> POOL = Lists.newArrayList();

      private PooledMutableBlockPos(int xIn, int yIn, int zIn) {
         super(xIn, yIn, zIn);
      }

      public PooledMutableBlockPos(BigInteger xIn, int yIn, BigInteger zIn) {
         super(xIn, yIn, zIn);
      }

      public static BlockPos.PooledMutableBlockPos retain() {
         return retain(0, 0, 0);
      }

      public static BlockPos.PooledMutableBlockPos retain(double xIn, double yIn, double zIn) {
         return retain(MathHelper.floor(xIn), MathHelper.floor(yIn), MathHelper.floor(zIn));
      }

      public static BlockPos.PooledMutableBlockPos retain(Vec3i vec) {
         return retain(vec.getX(), vec.getY(), vec.getZ());
      }

      public static BlockPos.PooledMutableBlockPos retain(int xIn, int yIn, int zIn) {
         return retain(BigInteger.valueOf((long)xIn), yIn, BigInteger.valueOf((long)zIn));
      }

      public static BlockPos.PooledMutableBlockPos retain(BigInteger xIn, int yIn, BigInteger zIn) {
         synchronized(POOL) {
            if (!POOL.isEmpty()) {
               BlockPos.PooledMutableBlockPos blockpos$pooledmutableblockpos = (BlockPos.PooledMutableBlockPos)POOL.remove(POOL.size() - 1);
               if (blockpos$pooledmutableblockpos != null && blockpos$pooledmutableblockpos.released) {
                  blockpos$pooledmutableblockpos.released = false;
                  blockpos$pooledmutableblockpos.setPos(xIn, yIn, zIn);
                  return blockpos$pooledmutableblockpos;
               }
            }
         }

         return new BlockPos.PooledMutableBlockPos(xIn, yIn, zIn);
      }

      public void release() {
         synchronized(POOL) {
            if (POOL.size() < 100) {
               POOL.add(this);
            }

            this.released = true;
         }
      }

      public BlockPos.PooledMutableBlockPos setPos(int xIn, int yIn, int zIn) {
         if (this.released) {
            BlockPos.LOGGER.error("PooledMutableBlockPosition modified after it was released.", new Throwable());
            this.released = false;
         }

         return (BlockPos.PooledMutableBlockPos)super.setPos(xIn, yIn, zIn);
      }

      public BlockPos.PooledMutableBlockPos setPos(Entity entityIn) {
         return (BlockPos.PooledMutableBlockPos)super.setPos(entityIn);
      }

      public BlockPos.PooledMutableBlockPos setPos(double xIn, double yIn, double zIn) {
         return (BlockPos.PooledMutableBlockPos)super.setPos(xIn, yIn, zIn);
      }

      public BlockPos.PooledMutableBlockPos setPos(Vec3i vec) {
         return (BlockPos.PooledMutableBlockPos)super.setPos(vec);
      }

      public BlockPos.PooledMutableBlockPos move(EnumFacing facing) {
         return (BlockPos.PooledMutableBlockPos)super.move(facing);
      }

      public BlockPos.PooledMutableBlockPos move(EnumFacing facing, int p_189534_2_) {
         return (BlockPos.PooledMutableBlockPos)super.move(facing, p_189534_2_);
      }
   }

   public static class MutableBlockPos extends BlockPos {
      protected BigInteger x;
      protected int y;
      protected BigInteger z;

      public MutableBlockPos() {
         this(0, 0, 0);
      }

      public MutableBlockPos(BlockPos pos) {
         this(pos.getX(), pos.getY(), pos.getZ());
      }

      public MutableBlockPos(int x_, int y_, int z_) {
         this(BigInteger.valueOf((long)x_), y_, BigInteger.valueOf((long)z_));
      }

      public MutableBlockPos(BigInteger x, int y, BigInteger z) {
         super(BigInteger.ZERO, 0, BigInteger.ZERO);
         this.x = x;
         this.y = y;
         this.z = z;
      }

      public BlockPos add(double x, double y, double z) {
         return super.add(x, y, z).toImmutable();
      }

      public BlockPos add(int x, int y, int z) {
         return super.add(x, y, z).toImmutable();
      }

      public BlockPos offset(EnumFacing facing, int n) {
         return super.offset(facing, n).toImmutable();
      }

      public BlockPos rotate(Rotation rotationIn) {
         return super.rotate(rotationIn).toImmutable();
      }

      public BigInteger getX() {
         return this.x;
      }

      public int getY() {
         return this.y;
      }

      public BigInteger getZ() {
         return this.z;
      }

      public BlockPos.MutableBlockPos setPos(int xIn, int yIn, int zIn) {
         return this.setPos(BigInteger.valueOf((long)xIn), yIn, BigInteger.valueOf((long)zIn));
      }

      public BlockPos.MutableBlockPos setPos(BigInteger x, int y, BigInteger z) {
         this.x = x;
         this.y = y;
         this.z = z;
         return this;
      }

      public BlockPos.MutableBlockPos setPos(Entity entityIn) {
         return this.setPos(entityIn.posX, entityIn.posY, entityIn.posZ);
      }

      public BlockPos.MutableBlockPos setPos(double xIn, double yIn, double zIn) {
         return this.setPos(MathHelper.floor_double_BigInteger(xIn), MathHelper.floor(yIn), MathHelper.floor_double_BigInteger(zIn));
      }

      public BlockPos.MutableBlockPos setPos(Vec3i vec) {
         return this.setPos(vec.getX(), vec.getY(), vec.getZ());
      }

      public BlockPos.MutableBlockPos move(EnumFacing facing) {
         return this.move(facing, 1);
      }

      public BlockPos.MutableBlockPos move(EnumFacing facing, int p_189534_2_) {
         return this.setPos(this.x.add(BigInteger.valueOf((long)(facing.getFrontOffsetX() * p_189534_2_))), this.y + facing.getFrontOffsetY() * p_189534_2_, this.z.add(BigInteger.valueOf((long)(facing.getFrontOffsetZ() * p_189534_2_))));
      }

      public void setY(int yIn) {
         this.y = yIn;
      }

      public BlockPos toImmutable() {
         return new BlockPos(this);
      }
   }
}
