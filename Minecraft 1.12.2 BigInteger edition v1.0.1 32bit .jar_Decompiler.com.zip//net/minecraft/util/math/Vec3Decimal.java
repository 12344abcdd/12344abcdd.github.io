package net.minecraft.util.math;

import java.math.BigDecimal;
import java.math.MathContext;
import javax.annotation.Nullable;

public class Vec3Decimal {
   public static final Vec3Decimal ZERO = new Vec3Decimal(0.0D, 0.0D, 0.0D);
   public static final MathContext CONTEXT = new MathContext(100);
   public static final BigDecimal EPSILON = new BigDecimal(1.0000000116860974E-7D);
   public final BigDecimal x;
   public final double y;
   public final BigDecimal z;

   public Vec3Decimal(double xIn, double yIn, double zIn) {
      if (xIn == -0.0D) {
         xIn = 0.0D;
      }

      if (yIn == -0.0D) {
         yIn = 0.0D;
      }

      if (zIn == -0.0D) {
         zIn = 0.0D;
      }

      this.x = new BigDecimal(xIn);
      this.y = yIn;
      this.z = new BigDecimal(zIn);
   }

   public Vec3Decimal(BigDecimal xIn, double yIn, BigDecimal zIn) {
      if (yIn == -0.0D) {
         yIn = 0.0D;
      }

      this.x = xIn;
      this.y = yIn;
      this.z = zIn;
   }

   public Vec3Decimal(Vec3i vector) {
      this(new BigDecimal(vector.getX()), (double)vector.getY(), new BigDecimal(vector.getZ()));
   }

   public Vec3Decimal subtract(Vec3Decimal vec) {
      return this.subtract(vec.x, vec.y, vec.z);
   }

   public Vec3Decimal subtract(double x, double y, double z) {
      return this.subtract(new BigDecimal(x), y, new BigDecimal(z));
   }

   public Vec3Decimal subtract(BigDecimal x, double y, BigDecimal z) {
      return this.addVector(x.negate(), -y, z.negate());
   }

   public Vec3Decimal add(Vec3Decimal vec) {
      return this.addVector(vec.x, vec.y, vec.z);
   }

   public Vec3Decimal addVector(double x, double y, double z) {
      return this.addVector(new BigDecimal(x), y, new BigDecimal(z));
   }

   public Vec3Decimal addVector(BigDecimal x, double y, BigDecimal z) {
      return new Vec3Decimal(this.x.add(x), this.y + y, this.z.add(z));
   }

   public double distanceTo(Vec3Decimal vec) {
      double d0 = vec.x.subtract(this.x).doubleValue();
      double d1 = vec.y - this.y;
      double d2 = vec.z.subtract(this.z).doubleValue();
      return (double)MathHelper.sqrt(d0 * d0 + d1 * d1 + d2 * d2);
   }

   public double squareDistanceTo(Vec3Decimal vec) {
      double d0 = vec.x.subtract(this.x).doubleValue();
      double d1 = vec.y - this.y;
      double d2 = vec.z.subtract(this.z).doubleValue();
      return d0 * d0 + d1 * d1 + d2 * d2;
   }

   public double squareDistanceTo(double xIn, double yIn, double zIn) {
      return this.squareDistanceTo(new BigDecimal(xIn), yIn, new BigDecimal(zIn));
   }

   public double squareDistanceTo(BigDecimal xIn, double yIn, BigDecimal zIn) {
      double d0 = xIn.subtract(this.x).doubleValue();
      double d1 = yIn - this.y;
      double d2 = zIn.subtract(this.z).doubleValue();
      return d0 * d0 + d1 * d1 + d2 * d2;
   }

   public Vec3Decimal scale(double p_186678_1_) {
      BigDecimal scale = new BigDecimal(p_186678_1_);
      return new Vec3Decimal(this.x.multiply(scale), this.y * p_186678_1_, this.z.multiply(scale));
   }

   public Vec3Decimal subtractReverse(Vec3Decimal vec) {
      return new Vec3Decimal(vec.x.subtract(this.x), vec.y - this.y, vec.z.subtract(this.z));
   }

   public boolean equals(Object p_equals_1_) {
      if (this == p_equals_1_) {
         return true;
      } else if (!(p_equals_1_ instanceof Vec3Decimal)) {
         return false;
      } else {
         Vec3Decimal vec3d = (Vec3Decimal)p_equals_1_;
         if (vec3d.x.compareTo(this.x) != 0) {
            return false;
         } else if (Double.compare(vec3d.y, this.y) != 0) {
            return false;
         } else {
            return vec3d.z.compareTo(this.z) == 0;
         }
      }
   }

   @Nullable
   public Vec3Decimal getIntermediateWithXValue(Vec3Decimal vec, BigDecimal x) {
      BigDecimal d0 = vec.x.subtract(this.x);
      double d1 = vec.y - this.y;
      BigDecimal d2 = vec.z.subtract(this.z);
      if (d0.multiply(d0, CONTEXT).compareTo(EPSILON) < 0) {
         return null;
      } else {
         BigDecimal d3 = x.subtract(this.x).divide(d0, CONTEXT);
         double d4 = d3.doubleValue();
         return d4 >= 0.0D && d4 <= 1.0D ? new Vec3Decimal(this.x.add(d0.multiply(d3, CONTEXT)), this.y + d1 * d4, this.z.add(d2.multiply(d3, CONTEXT))) : null;
      }
   }

   @Nullable
   public Vec3Decimal getIntermediateWithYValue(Vec3Decimal vec, double y) {
      BigDecimal d0 = vec.x.subtract(this.x);
      double d1 = vec.y - this.y;
      BigDecimal d2 = vec.z.subtract(this.z);
      if (d1 * d1 < 1.0000000116860974E-7D) {
         return null;
      } else {
         double d3 = (y - this.y) / d1;
         BigDecimal d4 = new BigDecimal(d3);
         return d3 >= 0.0D && d3 <= 1.0D ? new Vec3Decimal(this.x.add(d0.multiply(d4, CONTEXT)), this.y + d1 * d3, this.z.add(d2.multiply(d4, CONTEXT))) : null;
      }
   }

   @Nullable
   public Vec3Decimal getIntermediateWithZValue(Vec3Decimal vec, BigDecimal z) {
      BigDecimal d0 = vec.x.subtract(this.x);
      double d1 = vec.y - this.y;
      BigDecimal d2 = vec.z.subtract(this.z);
      if (d2.multiply(d2, CONTEXT).compareTo(EPSILON) < 0) {
         return null;
      } else {
         BigDecimal d3 = z.subtract(this.z).divide(d2, CONTEXT);
         double d4 = d3.doubleValue();
         return d4 >= 0.0D && d4 <= 1.0D ? new Vec3Decimal(this.x.add(d0.multiply(d3, CONTEXT)), this.y + d1 * d4, this.z.add(d2.multiply(d3, CONTEXT))) : null;
      }
   }

   public int hashCode() {
      long j = Double.doubleToLongBits(this.x.doubleValue());
      int i = (int)(j ^ j >>> 32);
      j = Double.doubleToLongBits(this.y);
      i = 31 * i + (int)(j ^ j >>> 32);
      j = Double.doubleToLongBits(this.z.doubleValue());
      i = 31 * i + (int)(j ^ j >>> 32);
      return i;
   }

   public String toString() {
      return "(" + this.x + ", " + this.y + ", " + this.z + ")";
   }

   public Vec3d toVec3d() {
      return new Vec3d(this.x.doubleValue(), this.y, this.z.doubleValue());
   }

   public Vec3Decimal setScale(int scale) {
      return new Vec3Decimal(this.x.setScale(scale, 6), this.y, this.z.setScale(scale, 6));
   }

   public static Vec3Decimal fromPitchYawVector(Vec2f p_189984_0_) {
      return fromPitchYaw(p_189984_0_.x, p_189984_0_.y);
   }

   public static Vec3Decimal fromPitchYaw(float p_189986_0_, float p_189986_1_) {
      float f = MathHelper.cos(-p_189986_1_ * 0.017453292F - 3.1415927F);
      float f1 = MathHelper.sin(-p_189986_1_ * 0.017453292F - 3.1415927F);
      float f2 = -MathHelper.cos(-p_189986_0_ * 0.017453292F);
      float f3 = MathHelper.sin(-p_189986_0_ * 0.017453292F);
      return new Vec3Decimal((double)(f1 * f2), (double)f3, (double)(f * f2));
   }
}
