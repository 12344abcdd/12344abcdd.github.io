package net.minecraft.util.math;

import net.minecraft.entity.Entity;
import net.minecraft.util.EnumFacing;

public class RayTraceResult {
   private BlockPos blockPos;
   public RayTraceResult.Type typeOfHit;
   public EnumFacing sideHit;
   public Vec3d hitVec;
   public Entity entityHit;
   public Vec3Decimal hitVecDecimal;

   public RayTraceResult(Vec3d hitVecIn, EnumFacing sideHitIn, BlockPos blockPosIn) {
      this(RayTraceResult.Type.BLOCK, hitVecIn, hitVecIn.toVec3Decimal(), sideHitIn, blockPosIn);
   }

   public RayTraceResult(Vec3d hitVecIn, EnumFacing sideHitIn) {
      this(RayTraceResult.Type.BLOCK, hitVecIn, hitVecIn.toVec3Decimal(), sideHitIn, BlockPos.ORIGIN);
   }

   public RayTraceResult(Vec3Decimal hitVecIn, EnumFacing sideHitIn, BlockPos blockPosIn) {
      this(RayTraceResult.Type.BLOCK, hitVecIn.toVec3d(), hitVecIn, sideHitIn, blockPosIn);
   }

   public RayTraceResult(Vec3Decimal hitVecIn, EnumFacing sideHitIn) {
      this(RayTraceResult.Type.BLOCK, hitVecIn.toVec3d(), hitVecIn, sideHitIn, BlockPos.ORIGIN);
   }

   public RayTraceResult(Entity entityIn) {
      this(entityIn, new Vec3d(entityIn.posX, entityIn.posY, entityIn.posZ));
   }

   public RayTraceResult(RayTraceResult.Type typeIn, Vec3d hitVecIn, Vec3Decimal hitVecIn2, EnumFacing sideHitIn, BlockPos blockPosIn) {
      this.typeOfHit = typeIn;
      this.blockPos = blockPosIn;
      this.sideHit = sideHitIn;
      this.hitVec = new Vec3d(hitVecIn.x, hitVecIn.y, hitVecIn.z);
      this.hitVecDecimal = hitVecIn2;
   }

   public RayTraceResult(Entity entityHitIn, Vec3d hitVecIn) {
      this.typeOfHit = RayTraceResult.Type.ENTITY;
      this.entityHit = entityHitIn;
      this.hitVec = hitVecIn;
      this.hitVecDecimal = hitVecIn.toVec3Decimal();
   }

   public RayTraceResult(Entity entityHitIn, Vec3Decimal hitVecIn) {
      this.typeOfHit = RayTraceResult.Type.ENTITY;
      this.entityHit = entityHitIn;
      this.hitVec = hitVecIn.toVec3d();
      this.hitVecDecimal = hitVecIn;
   }

   public BlockPos getBlockPos() {
      return this.blockPos;
   }

   public String toString() {
      return "HitResult{type=" + this.typeOfHit + ", blockpos=" + this.blockPos + ", f=" + this.sideHit + ", pos=" + this.hitVec + ", entity=" + this.entityHit + '}';
   }

   public static enum Type {
      MISS,
      BLOCK,
      ENTITY;
   }
}
