package net.minecraft.util.math;

import java.math.BigInteger;
import net.minecraft.entity.Entity;

public class ChunkPos {
   public final BigInteger x;
   public final BigInteger z;

   public ChunkPos(BigInteger x, BigInteger z) {
      this.x = x;
      this.z = z;
   }

   public ChunkPos(BlockPos pos) {
      this.x = pos.getX().shiftRight(4);
      this.z = pos.getZ().shiftRight(4);
   }

   public int hashCode() {
      int i = 1664525 * this.x.intValue() + 1013904223;
      int j = 1664525 * (this.z.intValue() ^ -559038737) + 1013904223;
      return i ^ j;
   }

   public boolean equals(Object p_equals_1_) {
      if (this == p_equals_1_) {
         return true;
      } else if (!(p_equals_1_ instanceof ChunkPos)) {
         return false;
      } else {
         ChunkPos chunkpos = (ChunkPos)p_equals_1_;
         return this.x.equals(chunkpos.x) && this.z.equals(chunkpos.z);
      }
   }

   public double getDistanceSq(Entity entityIn) {
      double d0 = this.x.shiftLeft(4).add(BigInteger.valueOf(8L)).doubleValue();
      double d1 = this.z.shiftLeft(4).add(BigInteger.valueOf(8L)).doubleValue();
      double d2 = d0 - entityIn.posX;
      double d3 = d1 - entityIn.posZ;
      return d2 * d2 + d3 * d3;
   }

   public BigInteger getXStart() {
      return this.x.shiftLeft(4);
   }

   public BigInteger getZStart() {
      return this.z.shiftLeft(4);
   }

   public BigInteger getXEnd() {
      return this.getXStart().add(BigInteger.valueOf(15L));
   }

   public BigInteger getZEnd() {
      return this.getZStart().add(BigInteger.valueOf(15L));
   }

   public BlockPos getBlock(int x, int y, int z) {
      return new BlockPos(this.getXStart().add(BigInteger.valueOf((long)x)), y, this.getZStart().add(BigInteger.valueOf((long)z)));
   }

   public String toString() {
      return "[" + this.x + ", " + this.z + "]";
   }

   public static ChunkPos asLong(int chunkX, int chunkZ) {
      return new ChunkPos(BigInteger.valueOf((long)chunkX), BigInteger.valueOf((long)chunkZ));
   }
}
