package net.minecraft.util.math;

import com.google.common.base.MoreObjects;
import java.math.BigDecimal;
import java.math.BigInteger;
import javax.annotation.concurrent.Immutable;

@Immutable
public class Vec3i implements Comparable<Vec3i> {
   public static final Vec3i NULL_VECTOR = new Vec3i(0, 0, 0);
   private final BigInteger x;
   private final int y;
   private final BigInteger z;

   public Vec3i(int xIn, int yIn, int zIn) {
      this.x = BigInteger.valueOf((long)xIn);
      this.y = yIn;
      this.z = BigInteger.valueOf((long)zIn);
   }

   public Vec3i(BigInteger xIn, int yIn, BigInteger zIn) {
      this.x = xIn;
      this.y = yIn;
      this.z = zIn;
   }

   public Vec3i(double xIn, double yIn, double zIn) {
      this(MathHelper.floor_double_BigInteger(xIn), MathHelper.floor(yIn), MathHelper.floor_double_BigInteger(zIn));
   }

   public Vec3i(BigDecimal xIn, double yIn, BigDecimal zIn) {
      this(MathHelper.floor_double_BigInteger(xIn), MathHelper.floor(yIn), MathHelper.floor_double_BigInteger(zIn));
   }

   public boolean equals(Object p_equals_1_) {
      if (this == p_equals_1_) {
         return true;
      } else if (!(p_equals_1_ instanceof Vec3i)) {
         return false;
      } else {
         Vec3i vec3i = (Vec3i)p_equals_1_;
         if (!this.getX().equals(vec3i.getX())) {
            return false;
         } else {
            return this.getY() != vec3i.getY() ? false : this.getZ().equals(vec3i.getZ());
         }
      }
   }

   public int hashCode() {
      return (this.getY() + this.getZ().intValue() * 31) * 31 + this.getX().intValue();
   }

   public int compareTo(Vec3i p_compareTo_1_) {
      if (this.getY() == p_compareTo_1_.getY()) {
         return this.getZ() == p_compareTo_1_.getZ() ? this.getX().subtract(p_compareTo_1_.getX()).intValueExact() : this.getZ().subtract(p_compareTo_1_.getZ()).intValueExact();
      } else {
         return this.getY() - p_compareTo_1_.getY();
      }
   }

   public BigInteger getX() {
      return this.x;
   }

   public int getY() {
      return this.y;
   }

   public BigInteger getZ() {
      return this.z;
   }

   public Vec3i crossProduct(Vec3i vec) {
      return new Vec3i(BigInteger.valueOf((long)this.getY()).multiply(vec.getZ()).subtract(this.getZ().multiply(BigInteger.valueOf((long)this.getY()))), this.getZ().multiply(vec.getX()).subtract(this.getX().multiply(vec.getZ())).intValueExact(), this.getX().multiply(BigInteger.valueOf((long)this.getY())).subtract(BigInteger.valueOf((long)this.getY()).multiply(vec.getX())));
   }

   public double getDistance(BigInteger xIn, int yIn, BigInteger zIn) {
      double d0 = this.getX().subtract(xIn).doubleValue();
      double d1 = (double)(this.getY() - yIn);
      double d2 = this.getZ().subtract(zIn).doubleValue();
      return Math.sqrt(d0 * d0 + d1 * d1 + d2 * d2);
   }

   public double distanceSq(double toX, double toY, double toZ) {
      double d0 = this.getX().doubleValue() - toX;
      double d1 = (double)this.getY() - toY;
      double d2 = this.getZ().doubleValue() - toZ;
      return d0 * d0 + d1 * d1 + d2 * d2;
   }

   public double distanceSqToCenter(double xIn, double yIn, double zIn) {
      double d0 = this.getX().doubleValue() + 0.5D - xIn;
      double d1 = (double)this.getY() + 0.5D - yIn;
      double d2 = this.getZ().doubleValue() + 0.5D - zIn;
      return d0 * d0 + d1 * d1 + d2 * d2;
   }

   public double distanceSq(Vec3i to) {
      return this.distanceSq(to.getX().doubleValue(), (double)to.getY(), to.getZ().doubleValue());
   }

   public String toString() {
      return MoreObjects.toStringHelper(this).add("x", this.getX()).add("y", this.getY()).add("z", this.getZ()).toString();
   }
}
