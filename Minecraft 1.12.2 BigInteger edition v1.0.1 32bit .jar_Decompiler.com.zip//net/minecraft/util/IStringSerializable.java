package net.minecraft.util;

public interface IStringSerializable {
   String getName();
}
