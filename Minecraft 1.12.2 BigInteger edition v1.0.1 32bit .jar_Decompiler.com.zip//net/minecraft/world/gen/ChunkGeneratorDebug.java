package net.minecraft.world.gen;

import com.google.common.collect.Lists;
import java.math.BigInteger;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkPrimer;

public class ChunkGeneratorDebug implements IChunkGenerator {
   private static final List<IBlockState> ALL_VALID_STATES = Lists.newArrayList();
   private static final int GRID_WIDTH;
   private static final int GRID_HEIGHT;
   protected static final IBlockState AIR;
   protected static final IBlockState BARRIER;
   private final World world;

   public ChunkGeneratorDebug(World worldIn) {
      this.world = worldIn;
   }

   public Chunk generateChunk(BigInteger x, BigInteger z) {
      ChunkPrimer chunkprimer = new ChunkPrimer();

      for(int i = 0; i < 16; ++i) {
         for(int j = 0; j < 16; ++j) {
            BigInteger k = x.shiftLeft(4).add(BigInteger.valueOf((long)i));
            BigInteger l = z.shiftLeft(4).add(BigInteger.valueOf((long)j));
            chunkprimer.setBlockState(i, 60, j, BARRIER);
            IBlockState iblockstate = getBlockStateFor(k.intValue(), l.intValue());
            if (iblockstate != null) {
               chunkprimer.setBlockState(i, 70, j, iblockstate);
            }
         }
      }

      Chunk chunk = new Chunk(this.world, chunkprimer, x, z);
      chunk.generateSkylightMap();
      Biome[] abiome = this.world.getBiomeProvider().getBiomes((Biome[])null, x.shiftLeft(4), z.shiftLeft(4), 16, 16);
      byte[] abyte = chunk.getBiomeArray();

      for(int i1 = 0; i1 < abyte.length; ++i1) {
         abyte[i1] = (byte)Biome.getIdForBiome(abiome[i1]);
      }

      chunk.generateSkylightMap();
      return chunk;
   }

   public static IBlockState getBlockStateFor(int x, int z) {
      IBlockState iblockstate = AIR;
      if (x > 0 && z > 0 && x % 2 != 0 && z % 2 != 0) {
         x /= 2;
         z /= 2;
         if (x <= GRID_WIDTH && z <= GRID_HEIGHT) {
            int i = MathHelper.abs(x * GRID_WIDTH + z);
            if (i < ALL_VALID_STATES.size()) {
               iblockstate = (IBlockState)ALL_VALID_STATES.get(i);
            }
         }
      }

      return iblockstate;
   }

   public void populate(BigInteger x, BigInteger z) {
   }

   public boolean generateStructures(Chunk chunkIn, BigInteger x, BigInteger z) {
      return false;
   }

   public List<Biome.SpawnListEntry> getPossibleCreatures(EnumCreatureType creatureType, BlockPos pos) {
      Biome biome = this.world.getBiome(pos);
      return biome.getSpawnableList(creatureType);
   }

   @Nullable
   public BlockPos getNearestStructurePos(World worldIn, String structureName, BlockPos position, boolean findUnexplored) {
      return null;
   }

   public boolean isInsideStructure(World worldIn, String structureName, BlockPos pos) {
      return false;
   }

   public void recreateStructures(Chunk chunkIn, BigInteger x, BigInteger z) {
   }

   static {
      AIR = Blocks.AIR.getDefaultState();
      BARRIER = Blocks.BARRIER.getDefaultState();
      Iterator var0 = Block.REGISTRY.iterator();

      while(var0.hasNext()) {
         Block block = (Block)var0.next();
         ALL_VALID_STATES.addAll(block.getBlockState().getValidStates());
      }

      GRID_WIDTH = MathHelper.ceil(MathHelper.sqrt((float)ALL_VALID_STATES.size()));
      GRID_HEIGHT = MathHelper.ceil((float)ALL_VALID_STATES.size() / (float)GRID_WIDTH);
   }
}
