package net.minecraft.world.gen.structure;

import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.Map.Entry;
import net.minecraft.init.Blocks;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.gen.structure.template.PlacementSettings;
import net.minecraft.world.gen.structure.template.Template;
import net.minecraft.world.gen.structure.template.TemplateManager;

public abstract class StructureComponentTemplate extends StructureComponent {
   private static final PlacementSettings DEFAULT_PLACE_SETTINGS = new PlacementSettings();
   protected Template template;
   protected PlacementSettings placeSettings;
   protected BlockPos templatePosition;

   public StructureComponentTemplate() {
      this.placeSettings = DEFAULT_PLACE_SETTINGS.setIgnoreEntities(true).setReplacedBlock(Blocks.AIR);
   }

   public StructureComponentTemplate(int type) {
      super(type);
      this.placeSettings = DEFAULT_PLACE_SETTINGS.setIgnoreEntities(true).setReplacedBlock(Blocks.AIR);
   }

   protected void setup(Template templateIn, BlockPos pos, PlacementSettings settings) {
      this.template = templateIn;
      this.setCoordBaseMode(EnumFacing.NORTH);
      this.templatePosition = pos;
      this.placeSettings = settings;
      this.setBoundingBoxFromTemplate();
   }

   protected void writeStructureToNBT(NBTTagCompound tagCompound) {
      tagCompound.setInteger("TPX", this.templatePosition.getX().intValueExact());
      tagCompound.setInteger("TPY", this.templatePosition.getY());
      tagCompound.setInteger("TPZ", this.templatePosition.getZ().intValueExact());
   }

   protected void readStructureFromNBT(NBTTagCompound tagCompound, TemplateManager p_143011_2_) {
      this.templatePosition = new BlockPos(tagCompound.getInteger("TPX"), tagCompound.getInteger("TPY"), tagCompound.getInteger("TPZ"));
   }

   public boolean addComponentParts(World worldIn, Random randomIn, StructureBoundingBox structureBoundingBoxIn) {
      this.placeSettings.setBoundingBox(structureBoundingBoxIn);
      this.template.addBlocksToWorld(worldIn, this.templatePosition, this.placeSettings, 18);
      Map<BlockPos, String> map = this.template.getDataBlocks(this.templatePosition, this.placeSettings);
      Iterator var5 = map.entrySet().iterator();

      while(var5.hasNext()) {
         Entry<BlockPos, String> entry = (Entry)var5.next();
         String s = (String)entry.getValue();
         this.handleDataMarker(s, (BlockPos)entry.getKey(), worldIn, randomIn, structureBoundingBoxIn);
      }

      return true;
   }

   protected abstract void handleDataMarker(String var1, BlockPos var2, World var3, Random var4, StructureBoundingBox var5);

   private void setBoundingBoxFromTemplate() {
      Rotation rotation = this.placeSettings.getRotation();
      BlockPos blockpos = this.template.transformedSize(rotation);
      Mirror mirror = this.placeSettings.getMirror();
      this.boundingBox = new StructureBoundingBox(0, 0, 0, blockpos.getX().intValueExact(), blockpos.getY() - 1, blockpos.getZ().intValueExact());
      switch(rotation) {
      case NONE:
      default:
         break;
      case CLOCKWISE_90:
         this.boundingBox.offset(-blockpos.getX().intValueExact(), 0, 0);
         break;
      case COUNTERCLOCKWISE_90:
         this.boundingBox.offset(0, 0, -blockpos.getZ().intValueExact());
         break;
      case CLOCKWISE_180:
         this.boundingBox.offset(-blockpos.getX().intValueExact(), 0, -blockpos.getZ().intValueExact());
      }

      switch(mirror) {
      case NONE:
      default:
         break;
      case FRONT_BACK:
         BlockPos blockpos2 = BlockPos.ORIGIN;
         if (rotation != Rotation.CLOCKWISE_90 && rotation != Rotation.COUNTERCLOCKWISE_90) {
            if (rotation == Rotation.CLOCKWISE_180) {
               blockpos2 = blockpos2.offset(EnumFacing.EAST, blockpos.getX().intValueExact());
            } else {
               blockpos2 = blockpos2.offset(EnumFacing.WEST, blockpos.getX().intValueExact());
            }
         } else {
            blockpos2 = blockpos2.offset(rotation.rotate(EnumFacing.WEST), blockpos.getZ().intValueExact());
         }

         this.boundingBox.offset(blockpos2.getX().intValueExact(), 0, blockpos2.getZ().intValueExact());
         break;
      case LEFT_RIGHT:
         BlockPos blockpos1 = BlockPos.ORIGIN;
         if (rotation != Rotation.CLOCKWISE_90 && rotation != Rotation.COUNTERCLOCKWISE_90) {
            if (rotation == Rotation.CLOCKWISE_180) {
               blockpos1 = blockpos1.offset(EnumFacing.SOUTH, blockpos.getZ().intValueExact());
            } else {
               blockpos1 = blockpos1.offset(EnumFacing.NORTH, blockpos.getZ().intValueExact());
            }
         } else {
            blockpos1 = blockpos1.offset(rotation.rotate(EnumFacing.NORTH), blockpos.getX().intValueExact());
         }

         this.boundingBox.offset(blockpos1.getX().intValueExact(), 0, blockpos1.getZ().intValueExact());
      }

      this.boundingBox.offset(this.templatePosition.getX().intValueExact(), this.templatePosition.getY(), this.templatePosition.getZ().intValueExact());
   }

   public void offset(int x, int y, int z) {
      super.offset(x, y, z);
      this.templatePosition = this.templatePosition.add(x, y, z);
   }
}
