package net.minecraft.world.gen;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import it.unimi.dsi.fastutil.objects.Object2ObjectMap;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import java.io.IOException;
import java.math.BigInteger;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import javax.annotation.Nullable;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.util.ReportedException;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.MinecraftException;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraft.world.chunk.storage.IChunkLoader;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ChunkProviderServer implements IChunkProvider {
   private static final Logger LOGGER = LogManager.getLogger();
   private final Set<ChunkPos> droppedChunksSet = Sets.newHashSet();
   private final IChunkGenerator chunkGenerator;
   private final IChunkLoader chunkLoader;
   private final Object2ObjectMap<ChunkPos, Chunk> id2ChunkMap = new Object2ObjectOpenHashMap(8192);
   private final WorldServer world;

   public ChunkProviderServer(WorldServer worldObjIn, IChunkLoader chunkLoaderIn, IChunkGenerator chunkGeneratorIn) {
      this.world = worldObjIn;
      this.chunkLoader = chunkLoaderIn;
      this.chunkGenerator = chunkGeneratorIn;
   }

   public Collection<Chunk> getLoadedChunks() {
      return this.id2ChunkMap.values();
   }

   public void queueUnload(Chunk chunkIn) {
      if (this.world.provider.canDropChunk(chunkIn.x, chunkIn.z)) {
         this.droppedChunksSet.add(new ChunkPos(chunkIn.x, chunkIn.z));
         chunkIn.unloadQueued = true;
      }

   }

   public void queueUnloadAll() {
      ObjectIterator objectiterator = this.id2ChunkMap.values().iterator();

      while(objectiterator.hasNext()) {
         Chunk chunk = (Chunk)objectiterator.next();
         this.queueUnload(chunk);
      }

   }

   @Nullable
   public Chunk getLoadedChunk(BigInteger x, BigInteger z) {
      ChunkPos i = new ChunkPos(x, z);
      Chunk chunk = (Chunk)this.id2ChunkMap.get(i);
      if (chunk != null) {
         chunk.unloadQueued = false;
      }

      return chunk;
   }

   @Nullable
   public Chunk loadChunk(BigInteger chunkX, BigInteger chunkZ) {
      Chunk chunk = this.getLoadedChunk(chunkX, chunkZ);
      if (chunk == null) {
         chunk = this.loadChunkFromFile(chunkX, chunkZ);
         if (chunk != null) {
            this.id2ChunkMap.put(new ChunkPos(chunkX, chunkZ), chunk);
            chunk.onLoad();
            chunk.populate(this, this.chunkGenerator);
         }
      }

      return chunk;
   }

   public Chunk provideChunk(BigInteger x, BigInteger z) {
      Chunk chunk = this.loadChunk(x, z);
      if (chunk == null) {
         ChunkPos i = new ChunkPos(x, z);

         try {
            chunk = this.chunkGenerator.generateChunk(x, z);
         } catch (Throwable var8) {
            CrashReport crashreport = CrashReport.makeCrashReport(var8, "Exception generating new chunk");
            CrashReportCategory crashreportcategory = crashreport.makeCategory("Chunk to be generated");
            crashreportcategory.addCrashSection("Location", String.format("%d,%d", x, z));
            crashreportcategory.addCrashSection("Generator", this.chunkGenerator);
            throw new ReportedException(crashreport);
         }

         this.id2ChunkMap.put(i, chunk);
         chunk.onLoad();
         chunk.populate(this, this.chunkGenerator);
      }

      return chunk;
   }

   @Nullable
   private Chunk loadChunkFromFile(BigInteger chunkX, BigInteger chunkZ) {
      try {
         Chunk chunk = this.chunkLoader.loadChunk(this.world, chunkX, chunkZ);
         if (chunk != null) {
            chunk.setLastSaveTime(this.world.getTotalWorldTime());
            this.chunkGenerator.recreateStructures(chunk, chunkX, chunkZ);
         }

         return chunk;
      } catch (Exception var4) {
         LOGGER.error("Couldn't load chunk", var4);
         return null;
      }
   }

   private void saveChunkExtraData(Chunk chunkIn) {
      try {
         this.chunkLoader.saveExtraChunkData(this.world, chunkIn);
      } catch (Exception var3) {
         LOGGER.error("Couldn't save entities", var3);
      }

   }

   private void saveChunkData(Chunk chunkIn) {
      try {
         chunkIn.setLastSaveTime(this.world.getTotalWorldTime());
         this.chunkLoader.saveChunk(this.world, chunkIn);
      } catch (IOException var3) {
         LOGGER.error("Couldn't save chunk", var3);
      } catch (MinecraftException var4) {
         LOGGER.error("Couldn't save chunk; already in use by another instance of Minecraft?", var4);
      }

   }

   public boolean saveChunks(boolean all) {
      int i = 0;
      List<Chunk> list = Lists.newArrayList(this.id2ChunkMap.values());

      for(int j = 0; j < list.size(); ++j) {
         Chunk chunk = (Chunk)list.get(j);
         if (all) {
            this.saveChunkExtraData(chunk);
         }

         if (chunk.needsSaving(all)) {
            this.saveChunkData(chunk);
            chunk.setModified(false);
            ++i;
            if (i == 24 && !all) {
               return false;
            }
         }
      }

      return true;
   }

   public void flushToDisk() {
      this.chunkLoader.flush();
   }

   public boolean tick() {
      if (!this.world.disableLevelSaving) {
         if (!this.droppedChunksSet.isEmpty()) {
            Iterator<ChunkPos> iterator = this.droppedChunksSet.iterator();

            for(int i = 0; i < 100 && iterator.hasNext(); iterator.remove()) {
               ChunkPos olong = (ChunkPos)iterator.next();
               Chunk chunk = (Chunk)this.id2ChunkMap.get(olong);
               if (chunk != null && chunk.unloadQueued) {
                  chunk.onUnload();
                  this.saveChunkData(chunk);
                  this.saveChunkExtraData(chunk);
                  this.id2ChunkMap.remove(olong);
                  ++i;
               }
            }
         }

         this.chunkLoader.chunkTick();
      }

      return false;
   }

   public boolean canSave() {
      return !this.world.disableLevelSaving;
   }

   public String makeString() {
      return "ServerChunkCache: " + this.id2ChunkMap.size() + " Drop: " + this.droppedChunksSet.size();
   }

   public List<Biome.SpawnListEntry> getPossibleCreatures(EnumCreatureType creatureType, BlockPos pos) {
      return this.chunkGenerator.getPossibleCreatures(creatureType, pos);
   }

   @Nullable
   public BlockPos getNearestStructurePos(World worldIn, String structureName, BlockPos position, boolean findUnexplored) {
      return this.chunkGenerator.getNearestStructurePos(worldIn, structureName, position, findUnexplored);
   }

   public boolean isInsideStructure(World worldIn, String structureName, BlockPos pos) {
      return this.chunkGenerator.isInsideStructure(worldIn, structureName, pos);
   }

   public int getLoadedChunkCount() {
      return this.id2ChunkMap.size();
   }

   public boolean chunkExists(BigInteger x, BigInteger z) {
      return this.id2ChunkMap.containsKey(new ChunkPos(x, z));
   }

   public boolean isChunkGeneratedAt(BigInteger x, BigInteger z) {
      return this.id2ChunkMap.containsKey(new ChunkPos(x, z)) || this.chunkLoader.isChunkGeneratedAt(x, z);
   }
}
