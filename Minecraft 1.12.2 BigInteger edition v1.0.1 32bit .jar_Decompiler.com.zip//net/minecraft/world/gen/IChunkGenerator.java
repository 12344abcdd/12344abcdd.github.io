package net.minecraft.world.gen;

import java.math.BigInteger;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.chunk.Chunk;

public interface IChunkGenerator {
   Chunk generateChunk(BigInteger var1, BigInteger var2);

   void populate(BigInteger var1, BigInteger var2);

   boolean generateStructures(Chunk var1, BigInteger var2, BigInteger var3);

   List<Biome.SpawnListEntry> getPossibleCreatures(EnumCreatureType var1, BlockPos var2);

   @Nullable
   BlockPos getNearestStructurePos(World var1, String var2, BlockPos var3, boolean var4);

   void recreateStructures(Chunk var1, BigInteger var2, BigInteger var3);

   boolean isInsideStructure(World var1, String var2, BlockPos var3);
}
