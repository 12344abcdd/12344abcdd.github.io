package net.minecraft.world.gen;

import java.math.BigInteger;
import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.BlockChorusFlower;
import net.minecraft.block.BlockFalling;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.init.Blocks;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityEndGateway;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkPrimer;
import net.minecraft.world.gen.feature.WorldGenEndGateway;
import net.minecraft.world.gen.feature.WorldGenEndIsland;
import net.minecraft.world.gen.structure.MapGenEndCity;

public class ChunkGeneratorEnd implements IChunkGenerator {
   private final Random rand;
   protected static final IBlockState END_STONE;
   protected static final IBlockState AIR;
   private final NoiseGeneratorOctaves lperlinNoise1;
   private final NoiseGeneratorOctaves lperlinNoise2;
   private final NoiseGeneratorOctaves perlinNoise1;
   public NoiseGeneratorOctaves noiseGen5;
   public NoiseGeneratorOctaves noiseGen6;
   private final World world;
   private final boolean mapFeaturesEnabled;
   private final BlockPos spawnPoint;
   private final MapGenEndCity endCityGen = new MapGenEndCity(this);
   private final NoiseGeneratorSimplex islandNoise;
   private double[] buffer;
   private Biome[] biomesForGeneration;
   double[] pnr;
   double[] ar;
   double[] br;
   private final WorldGenEndIsland endIslands = new WorldGenEndIsland();

   public ChunkGeneratorEnd(World p_i47241_1_, boolean p_i47241_2_, long p_i47241_3_, BlockPos p_i47241_5_) {
      this.world = p_i47241_1_;
      this.mapFeaturesEnabled = p_i47241_2_;
      this.spawnPoint = p_i47241_5_;
      this.rand = new Random(p_i47241_3_);
      this.lperlinNoise1 = new NoiseGeneratorOctaves(this.rand, 16);
      this.lperlinNoise2 = new NoiseGeneratorOctaves(this.rand, 16);
      this.perlinNoise1 = new NoiseGeneratorOctaves(this.rand, 8);
      this.noiseGen5 = new NoiseGeneratorOctaves(this.rand, 10);
      this.noiseGen6 = new NoiseGeneratorOctaves(this.rand, 16);
      this.islandNoise = new NoiseGeneratorSimplex(this.rand);
   }

   public void setBlocksInChunk(BigInteger x, BigInteger z, ChunkPrimer primer) {
      int i = true;
      int j = true;
      int k = true;
      int l = true;
      this.buffer = this.getHeights(this.buffer, x.multiply(BigInteger.valueOf(2L)), 0, z.multiply(BigInteger.valueOf(2L)), 3, 33, 3);

      for(int i1 = 0; i1 < 2; ++i1) {
         for(int j1 = 0; j1 < 2; ++j1) {
            for(int k1 = 0; k1 < 32; ++k1) {
               double d0 = 0.25D;
               double d1 = this.buffer[((i1 + 0) * 3 + j1 + 0) * 33 + k1 + 0];
               double d2 = this.buffer[((i1 + 0) * 3 + j1 + 1) * 33 + k1 + 0];
               double d3 = this.buffer[((i1 + 1) * 3 + j1 + 0) * 33 + k1 + 0];
               double d4 = this.buffer[((i1 + 1) * 3 + j1 + 1) * 33 + k1 + 0];
               double d5 = (this.buffer[((i1 + 0) * 3 + j1 + 0) * 33 + k1 + 1] - d1) * 0.25D;
               double d6 = (this.buffer[((i1 + 0) * 3 + j1 + 1) * 33 + k1 + 1] - d2) * 0.25D;
               double d7 = (this.buffer[((i1 + 1) * 3 + j1 + 0) * 33 + k1 + 1] - d3) * 0.25D;
               double d8 = (this.buffer[((i1 + 1) * 3 + j1 + 1) * 33 + k1 + 1] - d4) * 0.25D;

               for(int l1 = 0; l1 < 4; ++l1) {
                  double d9 = 0.125D;
                  double d10 = d1;
                  double d11 = d2;
                  double d12 = (d3 - d1) * 0.125D;
                  double d13 = (d4 - d2) * 0.125D;

                  for(int i2 = 0; i2 < 8; ++i2) {
                     double d14 = 0.125D;
                     double d15 = d10;
                     double d16 = (d11 - d10) * 0.125D;

                     for(int j2 = 0; j2 < 8; ++j2) {
                        IBlockState iblockstate = AIR;
                        if (d15 > 0.0D) {
                           iblockstate = END_STONE;
                        }

                        int k2 = i2 + i1 * 8;
                        int l2 = l1 + k1 * 4;
                        int i3 = j2 + j1 * 8;
                        primer.setBlockState(k2, l2, i3, iblockstate);
                        d15 += d16;
                     }

                     d10 += d12;
                     d11 += d13;
                  }

                  d1 += d5;
                  d2 += d6;
                  d3 += d7;
                  d4 += d8;
               }
            }
         }
      }

   }

   public void setBlocksInChunk(int x, int z, ChunkPrimer chunkprimer) {
      this.setBlocksInChunk(BigInteger.valueOf((long)x), BigInteger.valueOf((long)z), chunkprimer);
   }

   public void buildSurfaces(ChunkPrimer primer) {
      for(int i = 0; i < 16; ++i) {
         for(int j = 0; j < 16; ++j) {
            int k = true;
            int l = -1;
            IBlockState iblockstate = END_STONE;
            IBlockState iblockstate1 = END_STONE;

            for(int i1 = 127; i1 >= 0; --i1) {
               IBlockState iblockstate2 = primer.getBlockState(i, i1, j);
               if (iblockstate2.getMaterial() == Material.AIR) {
                  l = -1;
               } else if (iblockstate2.getBlock() == Blocks.STONE) {
                  if (l == -1) {
                     l = 1;
                     if (i1 >= 0) {
                        primer.setBlockState(i, i1, j, iblockstate);
                     } else {
                        primer.setBlockState(i, i1, j, iblockstate1);
                     }
                  } else if (l > 0) {
                     --l;
                     primer.setBlockState(i, i1, j, iblockstate1);
                  }
               }
            }
         }
      }

   }

   public Chunk generateChunk(BigInteger x, BigInteger z) {
      this.rand.setSeed((long)x.intValue() * 341873128712L + (long)z.intValue() * 132897987541L);
      ChunkPrimer chunkprimer = new ChunkPrimer();
      this.biomesForGeneration = this.world.getBiomeProvider().getBiomes(this.biomesForGeneration, x.shiftLeft(4), z.shiftLeft(4), 16, 16);
      this.setBlocksInChunk(x, z, chunkprimer);
      this.buildSurfaces(chunkprimer);
      if (this.mapFeaturesEnabled && x.bitLength() <= 26 && z.bitLength() <= 26) {
         this.endCityGen.generate(this.world, x.intValueExact(), z.intValueExact(), chunkprimer);
      }

      Chunk chunk = new Chunk(this.world, chunkprimer, x, z);
      byte[] abyte = chunk.getBiomeArray();

      for(int i = 0; i < abyte.length; ++i) {
         abyte[i] = (byte)Biome.getIdForBiome(this.biomesForGeneration[i]);
      }

      chunk.generateSkylightMap();
      return chunk;
   }

   private float getIslandHeightValue(BigInteger x, BigInteger z, int w, int h) {
      float f = x.multiply(BigInteger.valueOf(2L)).add(BigInteger.valueOf((long)w)).floatValue();
      float f1 = z.multiply(BigInteger.valueOf(2L)).add(BigInteger.valueOf((long)h)).floatValue();
      float f2 = 100.0F - MathHelper.sqrt(f * f + f1 * f1) * 8.0F;
      if (f2 > 80.0F) {
         f2 = 80.0F;
      }

      if (f2 < -100.0F) {
         f2 = -100.0F;
      }

      for(int i = -12; i <= 12; ++i) {
         for(int j = -12; j <= 12; ++j) {
            BigInteger k = x.add(BigInteger.valueOf((long)i));
            BigInteger l = z.add(BigInteger.valueOf((long)j));
            if (k.pow(2).add(l.pow(2)).compareTo(BigInteger.valueOf(4096L)) > 0 && this.islandNoise.getValue(k.doubleValue(), l.doubleValue()) < -0.8999999761581421D) {
               float f3 = (MathHelper.abs(k.floatValue()) * 3439.0F + MathHelper.abs(l.floatValue()) * 147.0F) % 13.0F + 9.0F;
               f = (float)(w - i * 2);
               f1 = (float)(h - j * 2);
               float f4 = 100.0F - MathHelper.sqrt(f * f + f1 * f1) * f3;
               if (f4 > 80.0F) {
                  f4 = 80.0F;
               }

               if (f4 < -100.0F) {
                  f4 = -100.0F;
               }

               if (f4 > f2) {
                  f2 = f4;
               }
            }
         }
      }

      return f2;
   }

   public boolean isIslandChunk(BigInteger x, BigInteger z) {
      return x.pow(2).add(z.pow(2)).compareTo(BigInteger.valueOf(4096L)) > 0 && this.getIslandHeightValue(x, z, 1, 1) >= 0.0F;
   }

   private double[] getHeights(double[] noiseTable, BigInteger x, int y, BigInteger z, int w, int h, int d) {
      if (noiseTable == null) {
         noiseTable = new double[w * h * d];
      }

      double d0 = 684.412D;
      double d1 = 684.412D;
      d0 *= 2.0D;
      this.pnr = this.perlinNoise1.generateNoiseOctaves(this.pnr, x, y, z, w, h, d, d0 / 80.0D, 4.277575000000001D, d0 / 80.0D);
      this.ar = this.lperlinNoise1.generateNoiseOctaves(this.ar, x, y, z, w, h, d, d0, 684.412D, d0);
      this.br = this.lperlinNoise2.generateNoiseOctaves(this.br, x, y, z, w, h, d, d0, 684.412D, d0);
      BigInteger i = x.divide(BigInteger.valueOf(2L));
      BigInteger j = z.divide(BigInteger.valueOf(2L));
      int k = 0;

      for(int l = 0; l < w; ++l) {
         for(int i1 = 0; i1 < d; ++i1) {
            float f = this.getIslandHeightValue(i, j, l, i1);

            for(int j1 = 0; j1 < h; ++j1) {
               double d2 = this.ar[k] / 512.0D;
               double d3 = this.br[k] / 512.0D;
               double d5 = (this.pnr[k] / 10.0D + 1.0D) / 2.0D;
               double d4;
               if (d5 < 0.0D) {
                  d4 = d2;
               } else if (d5 > 1.0D) {
                  d4 = d3;
               } else {
                  d4 = d2 + (d3 - d2) * d5;
               }

               d4 -= 8.0D;
               d4 += (double)f;
               int k1 = 2;
               double d7;
               if (j1 > h / 2 - k1) {
                  d7 = (double)((float)(j1 - (h / 2 - k1)) / 64.0F);
                  d7 = MathHelper.clamp(d7, 0.0D, 1.0D);
                  d4 = d4 * (1.0D - d7) + -3000.0D * d7;
               }

               k1 = 8;
               if (j1 < k1) {
                  d7 = (double)((float)(k1 - j1) / ((float)k1 - 1.0F));
                  d4 = d4 * (1.0D - d7) + -30.0D * d7;
               }

               noiseTable[k] = d4;
               ++k;
            }
         }
      }

      return noiseTable;
   }

   public void populate(BigInteger x, BigInteger z) {
      BlockFalling.fallInstantly = true;
      BlockPos blockpos = new BlockPos(x.shiftLeft(4), 0, z.shiftLeft(4));
      if (this.mapFeaturesEnabled && x.bitLength() <= 26 && z.bitLength() <= 26) {
         this.endCityGen.generateStructure(this.world, this.rand, new ChunkPos(x, z));
      }

      this.world.getBiome(blockpos.add(16, 0, 16)).decorate(this.world, this.world.rand, blockpos);
      BigInteger i = x.pow(2).add(z.pow(2));
      if (i.compareTo(BigInteger.valueOf(4096L)) > 0) {
         float f = this.getIslandHeightValue(x, z, 1, 1);
         if (f < -20.0F && this.rand.nextInt(14) == 0) {
            this.endIslands.generate(this.world, this.rand, blockpos.add(this.rand.nextInt(16) + 8, 55 + this.rand.nextInt(16), this.rand.nextInt(16) + 8));
            if (this.rand.nextInt(4) == 0) {
               this.endIslands.generate(this.world, this.rand, blockpos.add(this.rand.nextInt(16) + 8, 55 + this.rand.nextInt(16), this.rand.nextInt(16) + 8));
            }
         }

         if (this.getIslandHeightValue(x, z, 1, 1) > 40.0F) {
            int j = this.rand.nextInt(5);

            int l1;
            int i2;
            int j2;
            int k2;
            for(l1 = 0; l1 < j; ++l1) {
               i2 = this.rand.nextInt(16) + 8;
               j2 = this.rand.nextInt(16) + 8;
               k2 = this.world.getHeight(blockpos.add(i2, 0, j2)).getY();
               if (k2 > 0) {
                  int k1 = k2 - 1;
                  if (this.world.isAirBlock(blockpos.add(i2, k1 + 1, j2)) && this.world.getBlockState(blockpos.add(i2, k1, j2)).getBlock() == Blocks.END_STONE) {
                     BlockChorusFlower.generatePlant(this.world, blockpos.add(i2, k1 + 1, j2), this.rand, 8);
                  }
               }
            }

            if (this.rand.nextInt(700) == 0) {
               l1 = this.rand.nextInt(16) + 8;
               i2 = this.rand.nextInt(16) + 8;
               j2 = this.world.getHeight(blockpos.add(l1, 0, i2)).getY();
               if (j2 > 0) {
                  k2 = j2 + 3 + this.rand.nextInt(7);
                  BlockPos blockpos1 = blockpos.add(l1, k2, i2);
                  (new WorldGenEndGateway()).generate(this.world, this.rand, blockpos1);
                  TileEntity tileentity = this.world.getTileEntity(blockpos1);
                  if (tileentity instanceof TileEntityEndGateway) {
                     TileEntityEndGateway tileentityendgateway = (TileEntityEndGateway)tileentity;
                     tileentityendgateway.setExactPosition(this.spawnPoint);
                  }
               }
            }
         }
      }

      BlockFalling.fallInstantly = false;
   }

   public boolean generateStructures(Chunk chunkIn, BigInteger x, BigInteger z) {
      return false;
   }

   public List<Biome.SpawnListEntry> getPossibleCreatures(EnumCreatureType creatureType, BlockPos pos) {
      return this.world.getBiome(pos).getSpawnableList(creatureType);
   }

   @Nullable
   public BlockPos getNearestStructurePos(World worldIn, String structureName, BlockPos position, boolean findUnexplored) {
      return "EndCity".equals(structureName) && this.endCityGen != null ? this.endCityGen.getNearestStructurePos(worldIn, position, findUnexplored) : null;
   }

   public boolean isInsideStructure(World worldIn, String structureName, BlockPos pos) {
      return "EndCity".equals(structureName) && this.endCityGen != null ? this.endCityGen.isInsideStructure(pos) : false;
   }

   public void recreateStructures(Chunk chunkIn, BigInteger x, BigInteger z) {
   }

   static {
      END_STONE = Blocks.END_STONE.getDefaultState();
      AIR = Blocks.AIR.getDefaultState();
   }
}
