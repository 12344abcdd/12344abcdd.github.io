package net.minecraft.world.gen.feature;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class WorldGenIcePath extends WorldGenerator {
   private final Block block;
   private final int basePathWidth;

   public WorldGenIcePath(int basePathWidthIn) {
      this.block = Blocks.PACKED_ICE;
      this.basePathWidth = basePathWidthIn;
   }

   public boolean generate(World worldIn, Random rand, BlockPos position) {
      while(worldIn.isAirBlock(position) && position.getY() > 2) {
         position = position.down();
      }

      if (worldIn.getBlockState(position).getBlock() != Blocks.SNOW) {
         return false;
      } else {
         int i = rand.nextInt(this.basePathWidth - 2) + 2;
         int j = true;

         for(int k = -i; k <= i; ++k) {
            for(int l = -i; l <= i; ++l) {
               if (k * k + l * l <= i * i) {
                  for(int k1 = -1; k1 <= 1; ++k1) {
                     BlockPos blockpos = position.add(k, k1, l);
                     Block block = worldIn.getBlockState(blockpos).getBlock();
                     if (block == Blocks.DIRT || block == Blocks.SNOW || block == Blocks.ICE) {
                        worldIn.setBlockState(blockpos, this.block.getDefaultState(), 2);
                     }
                  }
               }
            }
         }

         return true;
      }
   }
}
