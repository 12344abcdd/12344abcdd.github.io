package net.minecraft.world.gen.feature;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class WorldGenClay extends WorldGenerator {
   private final Block block;
   private final int numberOfBlocks;

   public WorldGenClay(int p_i2011_1_) {
      this.block = Blocks.CLAY;
      this.numberOfBlocks = p_i2011_1_;
   }

   public boolean generate(World worldIn, Random rand, BlockPos position) {
      if (worldIn.getBlockState(position).getMaterial() != Material.WATER) {
         return false;
      } else {
         int i = rand.nextInt(this.numberOfBlocks - 2) + 2;
         int j = true;

         for(int k = -i; k <= i; ++k) {
            for(int l = -i; l <= i; ++l) {
               if (k * k + l * l <= i * i) {
                  for(int k1 = -1; k1 <= 1; ++k1) {
                     BlockPos blockpos = position.add(k, k1, l);
                     Block block = worldIn.getBlockState(blockpos).getBlock();
                     if (block == Blocks.DIRT || block == Blocks.CLAY) {
                        worldIn.setBlockState(blockpos, this.block.getDefaultState(), 2);
                     }
                  }
               }
            }
         }

         return true;
      }
   }
}
