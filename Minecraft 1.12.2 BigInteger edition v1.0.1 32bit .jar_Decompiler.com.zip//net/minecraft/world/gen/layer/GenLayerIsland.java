package net.minecraft.world.gen.layer;

import java.math.BigInteger;

public class GenLayerIsland extends GenLayer {
   public GenLayerIsland(long p_i2124_1_) {
      super(p_i2124_1_);
   }

   public int[] getInts(BigInteger areaX, BigInteger areaY, int areaWidth, int areaHeight) {
      int[] aint = IntCache.getIntCache(areaWidth * areaHeight);

      for(int i = 0; i < areaHeight; ++i) {
         for(int j = 0; j < areaWidth; ++j) {
            this.initChunkSeed((long)(areaX.intValue() + j), (long)(areaY.intValue() + i));
            aint[j + i * areaWidth] = this.nextInt(10) == 0 ? 1 : 0;
         }
      }

      if (areaX.compareTo(BigInteger.valueOf((long)(-areaWidth))) > 0 && areaX.signum() != 1 && areaY.compareTo(BigInteger.valueOf((long)(-areaHeight))) > 0 && areaY.signum() != 1) {
         aint[-areaX.intValueExact() + -areaY.intValueExact() * areaWidth] = 1;
      }

      return aint;
   }
}
