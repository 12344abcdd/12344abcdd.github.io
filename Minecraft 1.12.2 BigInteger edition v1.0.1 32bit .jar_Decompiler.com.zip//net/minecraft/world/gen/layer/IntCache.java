package net.minecraft.world.gen.layer;

import com.google.common.collect.Lists;
import java.util.List;

public class IntCache {
   private static int intCacheSize = 256;
   private static final List<int[]> freeSmallArrays = Lists.newArrayList();
   private static final List<int[]> inUseSmallArrays = Lists.newArrayList();
   private static final List<int[]> freeLargeArrays = Lists.newArrayList();
   private static final List<int[]> inUseLargeArrays = Lists.newArrayList();

   public static synchronized int[] getIntCache(int size) {
      int[] aint;
      if (size <= 256) {
         if (freeSmallArrays.isEmpty()) {
            aint = new int[256];
            inUseSmallArrays.add(aint);
            return aint;
         } else {
            aint = (int[])freeSmallArrays.remove(freeSmallArrays.size() - 1);
            inUseSmallArrays.add(aint);
            return aint;
         }
      } else if (size > intCacheSize) {
         intCacheSize = size;
         freeLargeArrays.clear();
         inUseLargeArrays.clear();
         aint = new int[intCacheSize];
         inUseLargeArrays.add(aint);
         return aint;
      } else if (freeLargeArrays.isEmpty()) {
         aint = new int[intCacheSize];
         inUseLargeArrays.add(aint);
         return aint;
      } else {
         aint = (int[])freeLargeArrays.remove(freeLargeArrays.size() - 1);
         inUseLargeArrays.add(aint);
         return aint;
      }
   }

   public static synchronized void resetIntCache() {
      if (!freeLargeArrays.isEmpty()) {
         freeLargeArrays.remove(freeLargeArrays.size() - 1);
      }

      if (!freeSmallArrays.isEmpty()) {
         freeSmallArrays.remove(freeSmallArrays.size() - 1);
      }

      freeLargeArrays.addAll(inUseLargeArrays);
      freeSmallArrays.addAll(inUseSmallArrays);
      inUseLargeArrays.clear();
      inUseSmallArrays.clear();
   }

   public static synchronized String getCacheSizes() {
      return "cache: " + freeLargeArrays.size() + ", tcache: " + freeSmallArrays.size() + ", allocated: " + inUseLargeArrays.size() + ", tallocated: " + inUseSmallArrays.size();
   }
}
