package net.minecraft.world.gen.layer;

import java.math.BigInteger;
import net.minecraft.init.Biomes;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.BiomeJungle;
import net.minecraft.world.biome.BiomeMesa;

public class GenLayerShore extends GenLayer {
   public GenLayerShore(long p_i2130_1_, GenLayer p_i2130_3_) {
      super(p_i2130_1_);
      this.parent = p_i2130_3_;
   }

   public int[] getInts(BigInteger areaX, BigInteger areaY, int areaWidth, int areaHeight) {
      int[] aint = this.parent.getInts(areaX.subtract(BigInteger.ONE), areaY.subtract(BigInteger.ONE), areaWidth + 2, areaHeight + 2);
      int[] aint1 = IntCache.getIntCache(areaWidth * areaHeight);

      for(int i = 0; i < areaHeight; ++i) {
         for(int j = 0; j < areaWidth; ++j) {
            this.initChunkSeed((long)(j + areaX.intValue()), (long)(i + areaY.intValue()));
            int k = aint[j + 1 + (i + 1) * (areaWidth + 2)];
            Biome biome = Biome.getBiome(k);
            int l;
            int i1;
            int j1;
            int k1;
            if (k == Biome.getIdForBiome(Biomes.MUSHROOM_ISLAND)) {
               l = aint[j + 1 + (i + 1 - 1) * (areaWidth + 2)];
               i1 = aint[j + 1 + 1 + (i + 1) * (areaWidth + 2)];
               j1 = aint[j + 1 - 1 + (i + 1) * (areaWidth + 2)];
               k1 = aint[j + 1 + (i + 1 + 1) * (areaWidth + 2)];
               if (l != Biome.getIdForBiome(Biomes.OCEAN) && i1 != Biome.getIdForBiome(Biomes.OCEAN) && j1 != Biome.getIdForBiome(Biomes.OCEAN) && k1 != Biome.getIdForBiome(Biomes.OCEAN)) {
                  aint1[j + i * areaWidth] = k;
               } else {
                  aint1[j + i * areaWidth] = Biome.getIdForBiome(Biomes.MUSHROOM_ISLAND_SHORE);
               }
            } else if (biome != null && biome.getBiomeClass() == BiomeJungle.class) {
               l = aint[j + 1 + (i + 1 - 1) * (areaWidth + 2)];
               i1 = aint[j + 1 + 1 + (i + 1) * (areaWidth + 2)];
               j1 = aint[j + 1 - 1 + (i + 1) * (areaWidth + 2)];
               k1 = aint[j + 1 + (i + 1 + 1) * (areaWidth + 2)];
               if (this.isJungleCompatible(l) && this.isJungleCompatible(i1) && this.isJungleCompatible(j1) && this.isJungleCompatible(k1)) {
                  if (!isBiomeOceanic(l) && !isBiomeOceanic(i1) && !isBiomeOceanic(j1) && !isBiomeOceanic(k1)) {
                     aint1[j + i * areaWidth] = k;
                  } else {
                     aint1[j + i * areaWidth] = Biome.getIdForBiome(Biomes.BEACH);
                  }
               } else {
                  aint1[j + i * areaWidth] = Biome.getIdForBiome(Biomes.JUNGLE_EDGE);
               }
            } else if (k != Biome.getIdForBiome(Biomes.EXTREME_HILLS) && k != Biome.getIdForBiome(Biomes.EXTREME_HILLS_WITH_TREES) && k != Biome.getIdForBiome(Biomes.EXTREME_HILLS_EDGE)) {
               if (biome != null && biome.isSnowyBiome()) {
                  this.replaceIfNeighborOcean(aint, aint1, j, i, areaWidth, k, Biome.getIdForBiome(Biomes.COLD_BEACH));
               } else if (k != Biome.getIdForBiome(Biomes.MESA) && k != Biome.getIdForBiome(Biomes.MESA_ROCK)) {
                  if (k != Biome.getIdForBiome(Biomes.OCEAN) && k != Biome.getIdForBiome(Biomes.DEEP_OCEAN) && k != Biome.getIdForBiome(Biomes.RIVER) && k != Biome.getIdForBiome(Biomes.SWAMPLAND)) {
                     l = aint[j + 1 + (i + 1 - 1) * (areaWidth + 2)];
                     i1 = aint[j + 1 + 1 + (i + 1) * (areaWidth + 2)];
                     j1 = aint[j + 1 - 1 + (i + 1) * (areaWidth + 2)];
                     k1 = aint[j + 1 + (i + 1 + 1) * (areaWidth + 2)];
                     if (!isBiomeOceanic(l) && !isBiomeOceanic(i1) && !isBiomeOceanic(j1) && !isBiomeOceanic(k1)) {
                        aint1[j + i * areaWidth] = k;
                     } else {
                        aint1[j + i * areaWidth] = Biome.getIdForBiome(Biomes.BEACH);
                     }
                  } else {
                     aint1[j + i * areaWidth] = k;
                  }
               } else {
                  l = aint[j + 1 + (i + 1 - 1) * (areaWidth + 2)];
                  i1 = aint[j + 1 + 1 + (i + 1) * (areaWidth + 2)];
                  j1 = aint[j + 1 - 1 + (i + 1) * (areaWidth + 2)];
                  k1 = aint[j + 1 + (i + 1 + 1) * (areaWidth + 2)];
                  if (!isBiomeOceanic(l) && !isBiomeOceanic(i1) && !isBiomeOceanic(j1) && !isBiomeOceanic(k1)) {
                     if (this.isMesa(l) && this.isMesa(i1) && this.isMesa(j1) && this.isMesa(k1)) {
                        aint1[j + i * areaWidth] = k;
                     } else {
                        aint1[j + i * areaWidth] = Biome.getIdForBiome(Biomes.DESERT);
                     }
                  } else {
                     aint1[j + i * areaWidth] = k;
                  }
               }
            } else {
               this.replaceIfNeighborOcean(aint, aint1, j, i, areaWidth, k, Biome.getIdForBiome(Biomes.STONE_BEACH));
            }
         }
      }

      return aint1;
   }

   private void replaceIfNeighborOcean(int[] p_151632_1_, int[] p_151632_2_, int p_151632_3_, int p_151632_4_, int p_151632_5_, int p_151632_6_, int p_151632_7_) {
      if (isBiomeOceanic(p_151632_6_)) {
         p_151632_2_[p_151632_3_ + p_151632_4_ * p_151632_5_] = p_151632_6_;
      } else {
         int i = p_151632_1_[p_151632_3_ + 1 + (p_151632_4_ + 1 - 1) * (p_151632_5_ + 2)];
         int j = p_151632_1_[p_151632_3_ + 1 + 1 + (p_151632_4_ + 1) * (p_151632_5_ + 2)];
         int k = p_151632_1_[p_151632_3_ + 1 - 1 + (p_151632_4_ + 1) * (p_151632_5_ + 2)];
         int l = p_151632_1_[p_151632_3_ + 1 + (p_151632_4_ + 1 + 1) * (p_151632_5_ + 2)];
         if (!isBiomeOceanic(i) && !isBiomeOceanic(j) && !isBiomeOceanic(k) && !isBiomeOceanic(l)) {
            p_151632_2_[p_151632_3_ + p_151632_4_ * p_151632_5_] = p_151632_6_;
         } else {
            p_151632_2_[p_151632_3_ + p_151632_4_ * p_151632_5_] = p_151632_7_;
         }
      }

   }

   private boolean isJungleCompatible(int p_151631_1_) {
      if (Biome.getBiome(p_151631_1_) != null && Biome.getBiome(p_151631_1_).getBiomeClass() == BiomeJungle.class) {
         return true;
      } else {
         return p_151631_1_ == Biome.getIdForBiome(Biomes.JUNGLE_EDGE) || p_151631_1_ == Biome.getIdForBiome(Biomes.JUNGLE) || p_151631_1_ == Biome.getIdForBiome(Biomes.JUNGLE_HILLS) || p_151631_1_ == Biome.getIdForBiome(Biomes.FOREST) || p_151631_1_ == Biome.getIdForBiome(Biomes.TAIGA) || isBiomeOceanic(p_151631_1_);
      }
   }

   private boolean isMesa(int p_151633_1_) {
      return Biome.getBiome(p_151633_1_) instanceof BiomeMesa;
   }
}
