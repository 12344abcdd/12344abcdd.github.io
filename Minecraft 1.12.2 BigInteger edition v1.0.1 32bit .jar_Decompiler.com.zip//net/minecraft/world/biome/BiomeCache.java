package net.minecraft.world.biome;

import com.google.common.collect.Lists;
import it.unimi.dsi.fastutil.objects.Object2ObjectMap;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import java.math.BigInteger;
import java.util.List;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.math.ChunkPos;

public class BiomeCache {
   private final BiomeProvider provider;
   private long lastCleanupTime;
   private final Object2ObjectMap<ChunkPos, BiomeCache.Block> cacheMap = new Object2ObjectOpenHashMap(4096);
   private final List<BiomeCache.Block> cache = Lists.newArrayList();

   public BiomeCache(BiomeProvider provider) {
      this.provider = provider;
   }

   public BiomeCache.Block getBiomeCacheBlock(BigInteger x, BigInteger z) {
      x = x.shiftRight(4);
      z = z.shiftRight(4);
      ChunkPos i = new ChunkPos(x, z);
      BiomeCache.Block biomecache$block = (BiomeCache.Block)this.cacheMap.get(i);
      if (biomecache$block == null) {
         biomecache$block = new BiomeCache.Block(x, z);
         this.cacheMap.put(i, biomecache$block);
         this.cache.add(biomecache$block);
      }

      biomecache$block.lastAccessTime = MinecraftServer.getCurrentTimeMillis();
      return biomecache$block;
   }

   public Biome getBiome(BigInteger x, BigInteger z, Biome defaultValue) {
      Biome biome = this.getBiomeCacheBlock(x, z).getBiome(x, z);
      return biome == null ? defaultValue : biome;
   }

   public void cleanupCache() {
      long i = MinecraftServer.getCurrentTimeMillis();
      long j = i - this.lastCleanupTime;
      if (j > 7500L || j < 0L) {
         this.lastCleanupTime = i;

         for(int k = 0; k < this.cache.size(); ++k) {
            BiomeCache.Block biomecache$block = (BiomeCache.Block)this.cache.get(k);
            long l = i - biomecache$block.lastAccessTime;
            if (l > 30000L || l < 0L) {
               this.cache.remove(k--);
               ChunkPos i1 = new ChunkPos(biomecache$block.x, biomecache$block.z);
               this.cacheMap.remove(i1);
            }
         }
      }

   }

   public Biome[] getCachedBiomes(BigInteger x, BigInteger z) {
      return this.getBiomeCacheBlock(x, z).biomes;
   }

   public class Block {
      public Biome[] biomes = new Biome[256];
      public BigInteger x;
      public BigInteger z;
      public long lastAccessTime;

      public Block(BigInteger x, BigInteger z) {
         this.x = x;
         this.z = z;
         BiomeCache.this.provider.getBiomes(this.biomes, x.shiftLeft(4), z.shiftLeft(4), 16, 16, false);
      }

      public Biome getBiome(BigInteger x, BigInteger z) {
         return this.biomes[x.intValue() & 15 | (z.intValue() & 15) << 4];
      }
   }
}
