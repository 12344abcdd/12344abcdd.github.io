package net.minecraft.world.biome;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.util.math.BlockPos;

public class BiomeProviderSingle extends BiomeProvider {
   private final Biome biome;

   public BiomeProviderSingle(Biome biomeIn) {
      this.biome = biomeIn;
   }

   public Biome getBiome(BlockPos pos) {
      return this.biome;
   }

   public Biome[] getBiomesForGeneration(Biome[] biomes, BigInteger x, BigInteger z, int width, int height) {
      if (biomes == null || biomes.length < width * height) {
         biomes = new Biome[width * height];
      }

      Arrays.fill(biomes, 0, width * height, this.biome);
      return biomes;
   }

   public Biome[] getBiomes(@Nullable Biome[] oldBiomeList, BigInteger x, BigInteger z, int width, int depth) {
      if (oldBiomeList == null || oldBiomeList.length < width * depth) {
         oldBiomeList = new Biome[width * depth];
      }

      Arrays.fill(oldBiomeList, 0, width * depth, this.biome);
      return oldBiomeList;
   }

   public Biome[] getBiomes(@Nullable Biome[] listToReuse, BigInteger x, BigInteger z, int width, int length, boolean cacheFlag) {
      return this.getBiomes(listToReuse, x, z, width, length);
   }

   @Nullable
   public BlockPos findBiomePosition(BigInteger x, BigInteger z, int range, List<Biome> biomes, Random random) {
      return biomes.contains(this.biome) ? new BlockPos(x.subtract(BigInteger.valueOf((long)(range + random.nextInt(range * 2 + 1)))), 0, z.subtract(BigInteger.valueOf((long)(range + random.nextInt(range * 2 + 1))))) : null;
   }

   public boolean areBiomesViable(BigInteger x, BigInteger z, int radius, List<Biome> allowed) {
      return allowed.contains(this.biome);
   }

   public boolean isFixedBiome() {
      return true;
   }

   public Biome getFixedBiome() {
      return this.biome;
   }
}
