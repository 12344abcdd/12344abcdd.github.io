package net.minecraft.world.biome;

import java.math.BigInteger;
import java.util.Random;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BiomeVoidDecorator extends BiomeDecorator {
   public void decorate(World worldIn, Random random, Biome biome, BlockPos pos) {
      BlockPos blockpos = worldIn.getSpawnPoint();
      int i = true;
      double d0 = blockpos.distanceSq(pos.add(8, blockpos.getY(), 8));
      if (d0 <= 1024.0D) {
         BlockPos blockpos1 = new BlockPos(blockpos.getX().subtract(BigInteger.valueOf(16L)), blockpos.getY() - 1, blockpos.getZ().subtract(BigInteger.valueOf(16L)));
         BlockPos blockpos2 = new BlockPos(blockpos.getX().add(BigInteger.valueOf(16L)), blockpos.getY() - 1, blockpos.getZ().add(BigInteger.valueOf(16L)));
         BlockPos.MutableBlockPos blockpos$mutableblockpos = new BlockPos.MutableBlockPos(blockpos1);
         BigInteger targetX = pos.getX().add(BigInteger.valueOf(16L));
         BigInteger targetZ = pos.getZ().add(BigInteger.valueOf(16L));

         for(BigInteger j = pos.getZ(); j.compareTo(targetX) < 0; j = j.add(BigInteger.ONE)) {
            for(BigInteger k = pos.getX(); k.compareTo(targetZ) < 0; k = k.add(BigInteger.ONE)) {
               if (j.compareTo(blockpos1.getZ()) >= 0 && j.compareTo(blockpos2.getZ()) <= 0 && k.compareTo(blockpos1.getX()) >= 0 && k.compareTo(blockpos2.getX()) <= 0) {
                  blockpos$mutableblockpos.setPos(k, blockpos$mutableblockpos.getY(), j);
                  if (blockpos.getX() == k && blockpos.getZ() == j) {
                     worldIn.setBlockState(blockpos$mutableblockpos, Blocks.COBBLESTONE.getDefaultState(), 2);
                  } else {
                     worldIn.setBlockState(blockpos$mutableblockpos, Blocks.STONE.getDefaultState(), 2);
                  }
               }
            }
         }
      }

   }
}
