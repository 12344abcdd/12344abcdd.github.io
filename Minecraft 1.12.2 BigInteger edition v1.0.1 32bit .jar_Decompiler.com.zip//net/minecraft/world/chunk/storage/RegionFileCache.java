package net.minecraft.world.chunk.storage;

import com.google.common.collect.Maps;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.math.BigInteger;
import java.util.Iterator;
import java.util.Map;

public class RegionFileCache {
   private static final Map<File, RegionFile> REGIONS_BY_FILE = Maps.newHashMap();

   public static synchronized RegionFile createOrLoadRegionFile(File worldDir, BigInteger chunkX, BigInteger chunkZ) {
      File file1 = new File(worldDir, "region");
      File file2 = new File(file1, "r." + chunkX.shiftRight(5) + "." + chunkZ.shiftRight(5) + ".mca");
      RegionFile regionfile = (RegionFile)REGIONS_BY_FILE.get(file2);
      if (regionfile != null) {
         return regionfile;
      } else {
         if (!file1.exists()) {
            file1.mkdirs();
         }

         if (REGIONS_BY_FILE.size() >= 256) {
            clearRegionFileReferences();
         }

         RegionFile regionfile1 = new RegionFile(file2);
         REGIONS_BY_FILE.put(file2, regionfile1);
         return regionfile1;
      }
   }

   public static synchronized RegionFile getRegionFileIfExists(File worldDir, BigInteger chunkX, BigInteger chunkZ) {
      File file1 = new File(worldDir, "region");
      File file2 = new File(file1, "r." + chunkX.shiftRight(4) + "." + chunkZ.shiftRight(4) + ".mca");
      RegionFile regionfile = (RegionFile)REGIONS_BY_FILE.get(file2);
      if (regionfile != null) {
         return regionfile;
      } else if (file1.exists() && file2.exists()) {
         if (REGIONS_BY_FILE.size() >= 256) {
            clearRegionFileReferences();
         }

         RegionFile regionfile1 = new RegionFile(file2);
         REGIONS_BY_FILE.put(file2, regionfile1);
         return regionfile1;
      } else {
         return null;
      }
   }

   public static synchronized void clearRegionFileReferences() {
      Iterator var0 = REGIONS_BY_FILE.values().iterator();

      while(var0.hasNext()) {
         RegionFile regionfile = (RegionFile)var0.next();

         try {
            if (regionfile != null) {
               regionfile.close();
            }
         } catch (IOException var3) {
            var3.printStackTrace();
         }
      }

      REGIONS_BY_FILE.clear();
   }

   public static DataInputStream getChunkInputStream(File worldDir, BigInteger chunkX, BigInteger chunkZ) {
      RegionFile regionfile = createOrLoadRegionFile(worldDir, chunkX, chunkZ);
      return regionfile.getChunkDataInputStream(chunkX.intValue() & 31, chunkZ.intValue() & 31);
   }

   public static DataOutputStream getChunkOutputStream(File worldDir, BigInteger chunkX, BigInteger chunkZ) {
      RegionFile regionfile = createOrLoadRegionFile(worldDir, chunkX, chunkZ);
      return regionfile.getChunkDataOutputStream(chunkX.intValue() & 31, chunkZ.intValue() & 31);
   }

   public static boolean chunkExists(File worldDir, BigInteger chunkX, BigInteger chunkZ) {
      RegionFile regionfile = getRegionFileIfExists(worldDir, chunkX, chunkZ);
      return regionfile != null ? regionfile.isChunkSaved(chunkX.intValue() & 31, chunkZ.intValue() & 31) : false;
   }
}
