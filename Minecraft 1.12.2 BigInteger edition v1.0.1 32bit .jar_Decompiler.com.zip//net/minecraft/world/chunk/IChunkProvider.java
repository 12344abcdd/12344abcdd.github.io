package net.minecraft.world.chunk;

import java.math.BigInteger;
import javax.annotation.Nullable;

public interface IChunkProvider {
   @Nullable
   Chunk getLoadedChunk(BigInteger var1, BigInteger var2);

   Chunk provideChunk(BigInteger var1, BigInteger var2);

   boolean tick();

   String makeString();

   boolean isChunkGeneratedAt(BigInteger var1, BigInteger var2);
}
