package net.minecraft.world.chunk;

import com.google.common.base.Predicate;
import com.google.common.collect.Maps;
import com.google.common.collect.Queues;
import java.math.BigInteger;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentLinkedQueue;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.block.ITileEntityProvider;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.crash.ICrashReportDetail;
import net.minecraft.entity.Entity;
import net.minecraft.init.Biomes;
import net.minecraft.init.Blocks;
import net.minecraft.network.PacketBuffer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ClassInheritanceMultiMap;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ReportedException;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BigDecimalAABB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.EnumSkyBlock;
import net.minecraft.world.World;
import net.minecraft.world.WorldType;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.BiomeProvider;
import net.minecraft.world.chunk.storage.ExtendedBlockStorage;
import net.minecraft.world.gen.ChunkGeneratorDebug;
import net.minecraft.world.gen.IChunkGenerator;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Chunk {
   private static final Logger LOGGER = LogManager.getLogger();
   public static final ExtendedBlockStorage NULL_BLOCK_STORAGE = null;
   private final ExtendedBlockStorage[] storageArrays;
   private final byte[] blockBiomeArray;
   private final int[] precipitationHeightMap;
   private final boolean[] updateSkylightColumns;
   private boolean loaded;
   private final World world;
   private final int[] heightMap;
   public final BigInteger x;
   public final BigInteger z;
   private boolean isGapLightingUpdated;
   private final Map<BlockPos, TileEntity> tileEntities;
   private final ClassInheritanceMultiMap<Entity>[] entityLists;
   private boolean isTerrainPopulated;
   private boolean isLightPopulated;
   private boolean ticked;
   private boolean dirty;
   private boolean hasEntities;
   private long lastSaveTime;
   private int heightMapMinimum;
   private long inhabitedTime;
   private int queuedLightChecks;
   private final ConcurrentLinkedQueue<BlockPos> tileEntityPosQueue;
   public boolean unloadQueued;

   public Chunk(World worldIn, BigInteger x, BigInteger z) {
      this.storageArrays = new ExtendedBlockStorage[16];
      this.blockBiomeArray = new byte[256];
      this.precipitationHeightMap = new int[256];
      this.updateSkylightColumns = new boolean[256];
      this.tileEntities = Maps.newHashMap();
      this.queuedLightChecks = 4096;
      this.tileEntityPosQueue = Queues.newConcurrentLinkedQueue();
      this.entityLists = (ClassInheritanceMultiMap[])(new ClassInheritanceMultiMap[16]);
      this.world = worldIn;
      this.x = x;
      this.z = z;
      this.heightMap = new int[256];

      for(int i = 0; i < this.entityLists.length; ++i) {
         this.entityLists[i] = new ClassInheritanceMultiMap(Entity.class);
      }

      Arrays.fill(this.precipitationHeightMap, -999);
      Arrays.fill(this.blockBiomeArray, (byte)-1);
   }

   public Chunk(World worldIn, ChunkPrimer primer, BigInteger x, BigInteger z) {
      this(worldIn, x, z);
      int i = true;
      boolean flag = worldIn.provider.hasSkyLight();

      for(int j = 0; j < 16; ++j) {
         for(int k = 0; k < 16; ++k) {
            for(int l = 0; l < 256; ++l) {
               IBlockState iblockstate = primer.getBlockState(j, l, k);
               if (iblockstate.getMaterial() != Material.AIR) {
                  int i1 = l >> 4;
                  if (this.storageArrays[i1] == NULL_BLOCK_STORAGE) {
                     this.storageArrays[i1] = new ExtendedBlockStorage(i1 << 4, flag);
                  }

                  this.storageArrays[i1].set(j, l & 15, k, iblockstate);
               }
            }
         }
      }

   }

   public boolean isAtLocation(BigInteger x, BigInteger z) {
      return x.equals(this.x) && z.equals(this.z);
   }

   public int getHeight(BlockPos pos) {
      return this.getHeightValue(pos.getX().intValue() & 15, pos.getZ().intValue() & 15);
   }

   public int getHeightValue(int x, int z) {
      return this.heightMap[z << 4 | x];
   }

   @Nullable
   private ExtendedBlockStorage getLastExtendedBlockStorage() {
      for(int i = this.storageArrays.length - 1; i >= 0; --i) {
         if (this.storageArrays[i] != NULL_BLOCK_STORAGE) {
            return this.storageArrays[i];
         }
      }

      return null;
   }

   public int getTopFilledSegment() {
      ExtendedBlockStorage extendedblockstorage = this.getLastExtendedBlockStorage();
      return extendedblockstorage == null ? 0 : extendedblockstorage.getYLocation();
   }

   public ExtendedBlockStorage[] getBlockStorageArray() {
      return this.storageArrays;
   }

   protected void generateHeightMap() {
      int i = this.getTopFilledSegment();
      this.heightMapMinimum = Integer.MAX_VALUE;

      for(int j = 0; j < 16; ++j) {
         for(int k = 0; k < 16; ++k) {
            this.precipitationHeightMap[j + (k << 4)] = -999;

            for(int l = i + 16; l > 0; --l) {
               IBlockState iblockstate = this.getBlockState(j, l - 1, k);
               if (iblockstate.getLightOpacity() != 0) {
                  this.heightMap[k << 4 | j] = l;
                  if (l < this.heightMapMinimum) {
                     this.heightMapMinimum = l;
                  }
                  break;
               }
            }
         }
      }

      this.dirty = true;
   }

   public void generateSkylightMap() {
      int i = this.getTopFilledSegment();
      this.heightMapMinimum = Integer.MAX_VALUE;

      for(int j = 0; j < 16; ++j) {
         for(int k = 0; k < 16; ++k) {
            this.precipitationHeightMap[j + (k << 4)] = -999;

            for(int l = i + 16; l > 0; --l) {
               if (this.getBlockLightOpacity(j, l - 1, k) != 0) {
                  this.heightMap[k << 4 | j] = l;
                  if (l < this.heightMapMinimum) {
                     this.heightMapMinimum = l;
                  }
                  break;
               }
            }
         }
      }

      this.dirty = true;
   }

   private void propagateSkylightOcclusion(int x, int z) {
      this.updateSkylightColumns[x + z * 16] = true;
      this.isGapLightingUpdated = true;
   }

   private void recheckGaps(boolean onlyOne) {
   }

   private void checkSkylightNeighborHeight(int x, int z, int maxValue) {
      int i = this.world.getHeight(new BlockPos(x, 0, z)).getY();
      if (i > maxValue) {
         this.updateSkylightNeighborHeight(x, z, maxValue, i + 1);
      } else if (i < maxValue) {
         this.updateSkylightNeighborHeight(x, z, i, maxValue + 1);
      }

   }

   private void updateSkylightNeighborHeight(int x, int z, int startY, int endY) {
      if (endY > startY && this.world.isAreaLoaded(new BlockPos(x, 0, z), 16)) {
         for(int i = startY; i < endY; ++i) {
            this.world.checkLightFor(EnumSkyBlock.SKY, new BlockPos(x, i, z));
         }

         this.dirty = true;
      }

   }

   private void relightBlock(int x, int y, int z) {
   }

   public int getBlockLightOpacity(BlockPos pos) {
      return this.getBlockState(pos).getLightOpacity();
   }

   private int getBlockLightOpacity(int x, int y, int z) {
      return this.getBlockState(x, y, z).getLightOpacity();
   }

   public IBlockState getBlockState(BlockPos pos) {
      return this.getBlockState(pos.getX().intValue(), pos.getY(), pos.getZ().intValue());
   }

   public IBlockState getBlockState(final int x, final int y, final int z) {
      if (this.world.getWorldType() == WorldType.DEBUG_ALL_BLOCK_STATES) {
         IBlockState iblockstate = null;
         if (y == 60) {
            iblockstate = Blocks.BARRIER.getDefaultState();
         }

         if (y == 70) {
            iblockstate = ChunkGeneratorDebug.getBlockStateFor(x, z);
         }

         return iblockstate == null ? Blocks.AIR.getDefaultState() : iblockstate;
      } else {
         try {
            if (y >= 0 && y >> 4 < this.storageArrays.length) {
               ExtendedBlockStorage extendedblockstorage = this.storageArrays[y >> 4];
               if (extendedblockstorage != NULL_BLOCK_STORAGE) {
                  return extendedblockstorage.get(x & 15, y & 15, z & 15);
               }
            }

            return Blocks.AIR.getDefaultState();
         } catch (Throwable var7) {
            CrashReport crashreport = CrashReport.makeCrashReport(var7, "Getting block state");
            CrashReportCategory crashreportcategory = crashreport.makeCategory("Block being got");
            crashreportcategory.addDetail("Location", new ICrashReportDetail<String>() {
               public String call() throws Exception {
                  return CrashReportCategory.getCoordinateInfo((double)x, (double)y, (double)z);
               }
            });
            throw new ReportedException(crashreport);
         }
      }
   }

   @Nullable
   public IBlockState setBlockState(BlockPos pos, IBlockState state) {
      int i = pos.getX().intValue() & 15;
      int j = pos.getY();
      int k = pos.getZ().intValue() & 15;
      int l = k << 4 | i;
      if (j >= this.precipitationHeightMap[l] - 1) {
         this.precipitationHeightMap[l] = -999;
      }

      int i1 = this.heightMap[l];
      IBlockState iblockstate = this.getBlockState(pos);
      if (iblockstate == state) {
         return null;
      } else {
         Block block = state.getBlock();
         Block block1 = iblockstate.getBlock();
         ExtendedBlockStorage extendedblockstorage = this.storageArrays[j >> 4];
         boolean flag = false;
         if (extendedblockstorage == NULL_BLOCK_STORAGE) {
            if (block == Blocks.AIR) {
               return null;
            }

            extendedblockstorage = new ExtendedBlockStorage(j >> 4 << 4, this.world.provider.hasSkyLight());
            this.storageArrays[j >> 4] = extendedblockstorage;
            flag = j >= i1;
         }

         extendedblockstorage.set(i, j & 15, k, state);
         if (block1 != block) {
            if (!this.world.isRemote) {
               block1.breakBlock(this.world, pos, iblockstate);
            } else if (block1 instanceof ITileEntityProvider) {
               this.world.removeTileEntity(pos);
            }
         }

         if (extendedblockstorage.get(i, j & 15, k).getBlock() != block) {
            return null;
         } else {
            if (flag) {
               this.generateSkylightMap();
            } else {
               int j1 = state.getLightOpacity();
               int k1 = iblockstate.getLightOpacity();
               if (j1 > 0) {
                  if (j >= i1) {
                     this.relightBlock(i, j + 1, k);
                  }
               } else if (j == i1 - 1) {
                  this.relightBlock(i, j, k);
               }

               if (j1 != k1 && (j1 < k1 || this.getLightFor(EnumSkyBlock.SKY, pos) > 0 || this.getLightFor(EnumSkyBlock.BLOCK, pos) > 0)) {
                  this.propagateSkylightOcclusion(i, k);
               }
            }

            TileEntity tileentity1;
            if (block1 instanceof ITileEntityProvider) {
               tileentity1 = this.getTileEntity(pos, Chunk.EnumCreateEntityType.CHECK);
               if (tileentity1 != null) {
                  tileentity1.updateContainingBlockInfo();
               }
            }

            if (!this.world.isRemote && block1 != block) {
               block.onBlockAdded(this.world, pos, state);
            }

            if (block instanceof ITileEntityProvider) {
               tileentity1 = this.getTileEntity(pos, Chunk.EnumCreateEntityType.CHECK);
               if (tileentity1 == null) {
                  tileentity1 = ((ITileEntityProvider)block).createNewTileEntity(this.world, block.getMetaFromState(state));
                  this.world.setTileEntity(pos, tileentity1);
               }

               if (tileentity1 != null) {
                  tileentity1.updateContainingBlockInfo();
               }
            }

            this.dirty = true;
            return iblockstate;
         }
      }
   }

   public int getLightFor(EnumSkyBlock type, BlockPos pos) {
      return 15;
   }

   public void setLightFor(EnumSkyBlock type, BlockPos pos, int value) {
   }

   public int getLightSubtracted(BlockPos pos, int amount) {
      return 15 - amount;
   }

   public void addEntity(Entity entityIn) {
      this.hasEntities = true;
      BigInteger i = MathHelper.floor_double_BigInteger(entityIn.posXBig).shiftRight(4);
      BigInteger j = MathHelper.floor_double_BigInteger(entityIn.posZBig).shiftRight(4);
      if (!i.equals(this.x) || !j.equals(this.z)) {
         LOGGER.warn("Wrong location! ({}, {}) should be ({}, {}), {}", i, j, this.x, this.z, entityIn);
         entityIn.setDead();
      }

      int k = MathHelper.floor(entityIn.posY / 16.0D);
      if (k < 0) {
         k = 0;
      }

      if (k >= this.entityLists.length) {
         k = this.entityLists.length - 1;
      }

      entityIn.addedToChunk = true;
      entityIn.chunkCoordX = this.x;
      entityIn.chunkCoordY = k;
      entityIn.chunkCoordZ = this.z;
      this.entityLists[k].add(entityIn);
   }

   public void removeEntity(Entity entityIn) {
      this.removeEntityAtIndex(entityIn, entityIn.chunkCoordY);
   }

   public void removeEntityAtIndex(Entity entityIn, int index) {
      if (index < 0) {
         index = 0;
      }

      if (index >= this.entityLists.length) {
         index = this.entityLists.length - 1;
      }

      this.entityLists[index].remove(entityIn);
   }

   public boolean canSeeSky(BlockPos pos) {
      return true;
   }

   @Nullable
   private TileEntity createNewTileEntity(BlockPos pos) {
      IBlockState iblockstate = this.getBlockState(pos);
      Block block = iblockstate.getBlock();
      return !block.hasTileEntity() ? null : ((ITileEntityProvider)block).createNewTileEntity(this.world, iblockstate.getBlock().getMetaFromState(iblockstate));
   }

   @Nullable
   public TileEntity getTileEntity(BlockPos pos, Chunk.EnumCreateEntityType p_177424_2_) {
      TileEntity tileentity = (TileEntity)this.tileEntities.get(pos);
      if (tileentity == null) {
         if (p_177424_2_ == Chunk.EnumCreateEntityType.IMMEDIATE) {
            tileentity = this.createNewTileEntity(pos);
            this.world.setTileEntity(pos, tileentity);
         } else if (p_177424_2_ == Chunk.EnumCreateEntityType.QUEUED) {
            this.tileEntityPosQueue.add(pos);
         }
      } else if (tileentity.isInvalid()) {
         this.tileEntities.remove(pos);
         return null;
      }

      return tileentity;
   }

   public void addTileEntity(TileEntity tileEntityIn) {
      this.addTileEntity(tileEntityIn.getPos(), tileEntityIn);
      if (this.loaded) {
         this.world.addTileEntity(tileEntityIn);
      }

   }

   public void addTileEntity(BlockPos pos, TileEntity tileEntityIn) {
      tileEntityIn.setWorld(this.world);
      tileEntityIn.setPos(pos);
      if (this.getBlockState(pos).getBlock() instanceof ITileEntityProvider) {
         if (this.tileEntities.containsKey(pos)) {
            ((TileEntity)this.tileEntities.get(pos)).invalidate();
         }

         tileEntityIn.validate();
         this.tileEntities.put(pos, tileEntityIn);
      }

   }

   public void removeTileEntity(BlockPos pos) {
      if (this.loaded) {
         TileEntity tileentity = (TileEntity)this.tileEntities.remove(pos);
         if (tileentity != null) {
            tileentity.invalidate();
         }
      }

   }

   public void onLoad() {
      this.loaded = true;
      this.world.addTileEntities(this.tileEntities.values());
      ClassInheritanceMultiMap[] var1 = this.entityLists;
      int var2 = var1.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         ClassInheritanceMultiMap<Entity> classinheritancemultimap = var1[var3];
         this.world.loadEntities(classinheritancemultimap);
      }

   }

   public void onUnload() {
      this.loaded = false;
      Iterator var1 = this.tileEntities.values().iterator();

      while(var1.hasNext()) {
         TileEntity tileentity = (TileEntity)var1.next();
         this.world.markTileEntityForRemoval(tileentity);
      }

      ClassInheritanceMultiMap[] var5 = this.entityLists;
      int var6 = var5.length;

      for(int var3 = 0; var3 < var6; ++var3) {
         ClassInheritanceMultiMap<Entity> classinheritancemultimap = var5[var3];
         this.world.unloadEntities(classinheritancemultimap);
      }

   }

   public void markDirty() {
      this.dirty = true;
   }

   public void getEntitiesWithinAABBForEntity(@Nullable Entity entityIn, AxisAlignedBB aabb, List<Entity> listToFill, Predicate<? super Entity> filter) {
      int j = this.entityLists.length - 1;

      label67:
      for(int k = 0; k <= j; ++k) {
         if (!this.entityLists[k].isEmpty()) {
            Iterator var7 = this.entityLists[k].iterator();

            while(true) {
               Entity[] aentity;
               do {
                  Entity entity;
                  do {
                     do {
                        if (!var7.hasNext()) {
                           continue label67;
                        }

                        entity = (Entity)var7.next();
                     } while(!entity.getEntityBoundingBox().intersects(aabb));
                  } while(entity == entityIn);

                  if (filter == null || filter.apply(entity)) {
                     listToFill.add(entity);
                  }

                  aentity = entity.getParts();
               } while(aentity == null);

               Entity[] var10 = aentity;
               int var11 = aentity.length;

               for(int var12 = 0; var12 < var11; ++var12) {
                  Entity entity1 = var10[var12];
                  if (entity1 != entityIn && entity1.getEntityBoundingBox().intersects(aabb) && (filter == null || filter.apply(entity1))) {
                     listToFill.add(entity1);
                  }
               }
            }
         }
      }

   }

   public void getEntitiesWithinAABBForEntity(@Nullable Entity entityIn, BigDecimalAABB aabb, List<Entity> listToFill, Predicate<? super Entity> filter) {
      int j = this.entityLists.length - 1;

      label67:
      for(int k = 0; k <= j; ++k) {
         if (!this.entityLists[k].isEmpty()) {
            Iterator var7 = this.entityLists[k].iterator();

            while(true) {
               Entity[] aentity;
               do {
                  Entity entity;
                  do {
                     do {
                        if (!var7.hasNext()) {
                           continue label67;
                        }

                        entity = (Entity)var7.next();
                     } while(!entity.getAABB().intersects(aabb));
                  } while(entity == entityIn);

                  if (filter == null || filter.apply(entity)) {
                     listToFill.add(entity);
                  }

                  aentity = entity.getParts();
               } while(aentity == null);

               Entity[] var10 = aentity;
               int var11 = aentity.length;

               for(int var12 = 0; var12 < var11; ++var12) {
                  Entity entity1 = var10[var12];
                  if (entity1 != entityIn && entity1.getAABB().intersects(aabb) && (filter == null || filter.apply(entity1))) {
                     listToFill.add(entity1);
                  }
               }
            }
         }
      }

   }

   public <T extends Entity> void getEntitiesOfTypeWithinAABB(Class<? extends T> entityClass, AxisAlignedBB aabb, List<T> listToFill, Predicate<? super T> filter) {
      int i = MathHelper.floor((aabb.minY - 2.0D) / 16.0D);
      int j = MathHelper.floor((aabb.maxY + 2.0D) / 16.0D);
      i = MathHelper.clamp(i, 0, this.entityLists.length - 1);
      j = MathHelper.clamp(j, 0, this.entityLists.length - 1);

      label33:
      for(int k = i; k <= j; ++k) {
         Iterator var8 = this.entityLists[k].getByClass(entityClass).iterator();

         while(true) {
            Entity t;
            do {
               do {
                  if (!var8.hasNext()) {
                     continue label33;
                  }

                  t = (Entity)var8.next();
               } while(!t.getEntityBoundingBox().intersects(aabb));
            } while(filter != null && !filter.apply(t));

            listToFill.add(t);
         }
      }

   }

   public boolean needsSaving(boolean p_76601_1_) {
      if (p_76601_1_) {
         if (this.hasEntities && this.world.getTotalWorldTime() != this.lastSaveTime || this.dirty) {
            return true;
         }
      } else if (this.hasEntities && this.world.getTotalWorldTime() >= this.lastSaveTime + 600L) {
         return true;
      }

      return this.dirty;
   }

   public Random getRandomWithSeed(long seed) {
      int x = this.x.intValue();
      int z = this.z.intValue();
      return new Random(this.world.getSeed() + (long)(x * x * 4987142) + (long)(x * 5947611) + (long)(z * z) * 4392871L + (long)(z * 389711) ^ seed);
   }

   public boolean isEmpty() {
      return false;
   }

   public void populate(IChunkProvider chunkProvider, IChunkGenerator chunkGenrator) {
      Chunk chunk = chunkProvider.getLoadedChunk(this.x, this.z.subtract(BigInteger.ONE));
      Chunk chunk1 = chunkProvider.getLoadedChunk(this.x.add(BigInteger.ONE), this.z);
      Chunk chunk2 = chunkProvider.getLoadedChunk(this.x, this.z.add(BigInteger.ONE));
      Chunk chunk3 = chunkProvider.getLoadedChunk(this.x.subtract(BigInteger.ONE), this.z);
      if (chunk1 != null && chunk2 != null && chunkProvider.getLoadedChunk(this.x.add(BigInteger.ONE), this.z.add(BigInteger.ONE)) != null) {
         this.populate(chunkGenrator);
      }

      if (chunk3 != null && chunk2 != null && chunkProvider.getLoadedChunk(this.x.subtract(BigInteger.ONE), this.z.add(BigInteger.ONE)) != null) {
         chunk3.populate(chunkGenrator);
      }

      if (chunk != null && chunk1 != null && chunkProvider.getLoadedChunk(this.x.add(BigInteger.ONE), this.z.subtract(BigInteger.ONE)) != null) {
         chunk.populate(chunkGenrator);
      }

      if (chunk != null && chunk3 != null) {
         Chunk chunk4 = chunkProvider.getLoadedChunk(this.x.subtract(BigInteger.ONE), this.z.subtract(BigInteger.ONE));
         if (chunk4 != null) {
            chunk4.populate(chunkGenrator);
         }
      }

   }

   protected void populate(IChunkGenerator generator) {
      if (this.isTerrainPopulated()) {
         if (generator.generateStructures(this, this.x, this.z)) {
            this.markDirty();
         }
      } else {
         this.checkLight();
         generator.populate(this.x, this.z);
         this.markDirty();
      }

   }

   public BlockPos getPrecipitationHeight(BlockPos pos) {
      int i = pos.getX().intValue() & 15;
      int j = pos.getZ().intValue() & 15;
      int k = i | j << 4;
      BlockPos blockpos = new BlockPos(pos.getX(), this.precipitationHeightMap[k], pos.getZ());
      if (blockpos.getY() == -999) {
         int l = this.getTopFilledSegment() + 15;
         blockpos = new BlockPos(pos.getX(), l, pos.getZ());
         int i1 = -1;

         while(true) {
            while(blockpos.getY() > 0 && i1 == -1) {
               IBlockState iblockstate = this.getBlockState(blockpos);
               Material material = iblockstate.getMaterial();
               if (!material.blocksMovement() && !material.isLiquid()) {
                  blockpos = blockpos.down();
               } else {
                  i1 = blockpos.getY() + 1;
               }
            }

            this.precipitationHeightMap[k] = i1;
            break;
         }
      }

      return new BlockPos(pos.getX(), this.precipitationHeightMap[k], pos.getZ());
   }

   public void onTick(boolean skipRecheckGaps) {
      if (this.isGapLightingUpdated && this.world.provider.hasSkyLight() && !skipRecheckGaps) {
         this.recheckGaps(this.world.isRemote);
      }

      this.ticked = true;
      if (!this.isLightPopulated && this.isTerrainPopulated) {
         this.checkLight();
      }

      while(!this.tileEntityPosQueue.isEmpty()) {
         BlockPos blockpos = (BlockPos)this.tileEntityPosQueue.poll();
         if (this.getTileEntity(blockpos, Chunk.EnumCreateEntityType.CHECK) == null && this.getBlockState(blockpos).getBlock().hasTileEntity()) {
            TileEntity tileentity = this.createNewTileEntity(blockpos);
            this.world.setTileEntity(blockpos, tileentity);
            this.world.markBlockRangeForRenderUpdate(blockpos, blockpos);
         }
      }

   }

   public boolean isPopulated() {
      return this.ticked && this.isTerrainPopulated;
   }

   public boolean wasTicked() {
      return this.ticked;
   }

   public ChunkPos getPos() {
      return new ChunkPos(this.x, this.z);
   }

   public boolean isEmptyBetween(int startY, int endY) {
      if (startY < 0) {
         startY = 0;
      }

      if (endY >= 256) {
         endY = 255;
      }

      for(int i = startY; i <= endY; i += 16) {
         ExtendedBlockStorage extendedblockstorage = this.storageArrays[i >> 4];
         if (extendedblockstorage != NULL_BLOCK_STORAGE && !extendedblockstorage.isEmpty()) {
            return false;
         }
      }

      return true;
   }

   public void setStorageArrays(ExtendedBlockStorage[] newStorageArrays) {
      if (this.storageArrays.length != newStorageArrays.length) {
         LOGGER.warn("Could not set level chunk sections, array length is {} instead of {}", newStorageArrays.length, this.storageArrays.length);
      } else {
         System.arraycopy(newStorageArrays, 0, this.storageArrays, 0, this.storageArrays.length);
      }

   }

   public void read(PacketBuffer buf, int availableSections, boolean groundUpContinuous) {
      boolean flag = this.world.provider.hasSkyLight();

      int j;
      for(j = 0; j < this.storageArrays.length; ++j) {
         ExtendedBlockStorage extendedblockstorage = this.storageArrays[j];
         if ((availableSections & 1 << j) == 0) {
            if (groundUpContinuous && extendedblockstorage != NULL_BLOCK_STORAGE) {
               this.storageArrays[j] = NULL_BLOCK_STORAGE;
            }
         } else {
            if (extendedblockstorage == NULL_BLOCK_STORAGE) {
               extendedblockstorage = new ExtendedBlockStorage(j << 4, flag);
               this.storageArrays[j] = extendedblockstorage;
            }

            extendedblockstorage.getData().read(buf);
            buf.readBytes(extendedblockstorage.getBlockLight().getData());
            if (flag) {
               buf.readBytes(extendedblockstorage.getSkyLight().getData());
            }
         }
      }

      if (groundUpContinuous) {
         buf.readBytes(this.blockBiomeArray);
      }

      for(j = 0; j < this.storageArrays.length; ++j) {
         if (this.storageArrays[j] != NULL_BLOCK_STORAGE && (availableSections & 1 << j) != 0) {
            this.storageArrays[j].recalculateRefCounts();
         }
      }

      this.isLightPopulated = true;
      this.isTerrainPopulated = true;
      this.generateHeightMap();
      Iterator var7 = this.tileEntities.values().iterator();

      while(var7.hasNext()) {
         TileEntity tileentity = (TileEntity)var7.next();
         tileentity.updateContainingBlockInfo();
      }

   }

   public Biome getBiome(BlockPos pos, BiomeProvider provider) {
      int i = pos.getX().intValue() & 15;
      int j = pos.getZ().intValue() & 15;
      int k = this.blockBiomeArray[j << 4 | i] & 255;
      Biome biome1;
      if (k == 255) {
         biome1 = provider.getBiome(pos, Biomes.PLAINS);
         k = Biome.getIdForBiome(biome1);
         this.blockBiomeArray[j << 4 | i] = (byte)(k & 255);
      }

      biome1 = Biome.getBiome(k);
      return biome1 == null ? Biomes.PLAINS : biome1;
   }

   public byte[] getBiomeArray() {
      return this.blockBiomeArray;
   }

   public void setBiomeArray(byte[] biomeArray) {
      if (this.blockBiomeArray.length != biomeArray.length) {
         LOGGER.warn("Could not set level chunk biomes, array length is {} instead of {}", biomeArray.length, this.blockBiomeArray.length);
      } else {
         System.arraycopy(biomeArray, 0, this.blockBiomeArray, 0, this.blockBiomeArray.length);
      }

   }

   public void resetRelightChecks() {
      this.queuedLightChecks = 0;
   }

   public void enqueueRelightChecks() {
   }

   public void checkLight() {
      this.isTerrainPopulated = true;
      this.isLightPopulated = true;
   }

   private void setSkylightUpdated() {
   }

   private void checkLightSide(EnumFacing facing) {
   }

   private boolean checkLight(int x, int z) {
      return true;
   }

   public boolean isLoaded() {
      return this.loaded;
   }

   public void markLoaded(boolean loaded) {
      this.loaded = loaded;
   }

   public World getWorld() {
      return this.world;
   }

   public int[] getHeightMap() {
      return this.heightMap;
   }

   public void setHeightMap(int[] newHeightMap) {
      if (this.heightMap.length != newHeightMap.length) {
         LOGGER.warn("Could not set level chunk heightmap, array length is {} instead of {}", newHeightMap.length, this.heightMap.length);
      } else {
         System.arraycopy(newHeightMap, 0, this.heightMap, 0, this.heightMap.length);
      }

   }

   public Map<BlockPos, TileEntity> getTileEntityMap() {
      return this.tileEntities;
   }

   public ClassInheritanceMultiMap<Entity>[] getEntityLists() {
      return this.entityLists;
   }

   public boolean isTerrainPopulated() {
      return this.isTerrainPopulated;
   }

   public void setTerrainPopulated(boolean terrainPopulated) {
      this.isTerrainPopulated = terrainPopulated;
   }

   public boolean isLightPopulated() {
      return this.isLightPopulated;
   }

   public void setLightPopulated(boolean lightPopulated) {
      this.isLightPopulated = lightPopulated;
   }

   public void setModified(boolean modified) {
      this.dirty = modified;
   }

   public void setHasEntities(boolean hasEntitiesIn) {
      this.hasEntities = hasEntitiesIn;
   }

   public void setLastSaveTime(long saveTime) {
      this.lastSaveTime = saveTime;
   }

   public int getLowestHeight() {
      return this.heightMapMinimum;
   }

   public long getInhabitedTime() {
      return this.inhabitedTime;
   }

   public void setInhabitedTime(long newInhabitedTime) {
      this.inhabitedTime = newInhabitedTime;
   }

   public static enum EnumCreateEntityType {
      IMMEDIATE,
      QUEUED,
      CHECK;
   }
}
