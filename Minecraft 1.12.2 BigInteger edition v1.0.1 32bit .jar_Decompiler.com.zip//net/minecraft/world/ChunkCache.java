package net.minecraft.world;

import java.math.BigInteger;
import javax.annotation.Nullable;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.chunk.Chunk;

public class ChunkCache implements IBlockAccess {
   protected BigInteger chunkX;
   protected BigInteger chunkZ;
   protected Chunk[][] chunkArray;
   protected boolean empty;
   protected World world;

   public ChunkCache(World worldIn, BlockPos posFromIn, BlockPos posToIn, int subIn) {
      this.world = worldIn;
      BigInteger in = BigInteger.valueOf((long)subIn);
      this.chunkX = posFromIn.getX().subtract(in).shiftRight(4);
      this.chunkZ = posFromIn.getZ().subtract(in).shiftRight(4);
      BigInteger i = posToIn.getX().add(in).shiftRight(4);
      BigInteger j = posToIn.getZ().add(in).shiftRight(4);
      this.chunkArray = new Chunk[i.subtract(this.chunkX).intValueExact() + 1][j.subtract(this.chunkZ).intValueExact() + 1];
      this.empty = true;

      BigInteger targetX;
      BigInteger targetZ;
      for(targetX = this.chunkX; targetX.compareTo(i) <= 0; targetX = targetX.add(BigInteger.ONE)) {
         for(targetZ = this.chunkZ; targetZ.compareTo(j) <= 0; targetZ = targetZ.add(BigInteger.ONE)) {
            this.chunkArray[targetX.subtract(this.chunkX).intValueExact()][targetZ.subtract(this.chunkZ).intValueExact()] = worldIn.getChunkFromChunkCoords(targetX, targetZ);
         }
      }

      targetX = posToIn.getX().shiftRight(4);
      targetZ = posToIn.getZ().shiftRight(4);

      for(BigInteger i1 = posFromIn.getX().shiftRight(4); i1.compareTo(targetX) <= 0; i1 = i1.add(BigInteger.ONE)) {
         for(BigInteger j1 = posFromIn.getZ().shiftRight(4); j1.compareTo(targetZ) <= 0; j1 = j1.add(BigInteger.ONE)) {
            Chunk chunk = this.chunkArray[i1.subtract(this.chunkX).intValueExact()][j1.subtract(this.chunkZ).intValueExact()];
            if (chunk != null && !chunk.isEmptyBetween(posFromIn.getY(), posToIn.getY())) {
               this.empty = false;
            }
         }
      }

   }

   public boolean isEmpty() {
      return this.empty;
   }

   @Nullable
   public TileEntity getTileEntity(BlockPos pos) {
      return this.getTileEntity(pos, Chunk.EnumCreateEntityType.IMMEDIATE);
   }

   @Nullable
   public TileEntity getTileEntity(BlockPos pos, Chunk.EnumCreateEntityType p_190300_2_) {
      int i = pos.getX().shiftRight(4).subtract(this.chunkX).intValueExact();
      int j = pos.getZ().shiftRight(4).subtract(this.chunkZ).intValueExact();
      return this.chunkArray[i][j].getTileEntity(pos, p_190300_2_);
   }

   public int getCombinedLight(BlockPos pos, int lightValue) {
      int i = this.getLightForExt(EnumSkyBlock.SKY, pos);
      int j = this.getLightForExt(EnumSkyBlock.BLOCK, pos);
      if (j < lightValue) {
         j = lightValue;
      }

      return i << 20 | j << 4;
   }

   public IBlockState getBlockState(BlockPos pos) {
      if (pos.getY() >= 0 && pos.getY() < 256) {
         int i = pos.getX().shiftRight(4).subtract(this.chunkX).intValueExact();
         int j = pos.getZ().shiftRight(4).subtract(this.chunkZ).intValueExact();
         if (i >= 0 && i < this.chunkArray.length && j >= 0 && j < this.chunkArray[i].length) {
            Chunk chunk = this.chunkArray[i][j];
            if (chunk != null) {
               return chunk.getBlockState(pos);
            }
         }
      }

      return Blocks.AIR.getDefaultState();
   }

   public Biome getBiome(BlockPos pos) {
      int i = pos.getX().shiftRight(4).subtract(this.chunkX).intValueExact();
      int j = pos.getZ().shiftRight(4).subtract(this.chunkZ).intValueExact();
      return this.chunkArray[i][j].getBiome(pos, this.world.getBiomeProvider());
   }

   private int getLightForExt(EnumSkyBlock type, BlockPos pos) {
      if (type == EnumSkyBlock.SKY && !this.world.provider.hasSkyLight()) {
         return 0;
      } else if (pos.getY() >= 0 && pos.getY() < 256) {
         int l;
         if (this.getBlockState(pos).useNeighborBrightness()) {
            l = 0;
            EnumFacing[] var9 = EnumFacing.values();
            int var5 = var9.length;

            for(int var6 = 0; var6 < var5; ++var6) {
               EnumFacing enumfacing = var9[var6];
               int k = this.getLightFor(type, pos.offset(enumfacing));
               if (k > l) {
                  l = k;
               }

               if (l >= 15) {
                  return l;
               }
            }

            return l;
         } else {
            l = pos.getX().shiftRight(4).subtract(this.chunkX).intValueExact();
            int j = pos.getZ().shiftRight(4).subtract(this.chunkZ).intValueExact();
            return this.chunkArray[l][j].getLightFor(type, pos);
         }
      } else {
         return type.defaultLightValue;
      }
   }

   public boolean isAirBlock(BlockPos pos) {
      return this.getBlockState(pos).getMaterial() == Material.AIR;
   }

   public int getLightFor(EnumSkyBlock type, BlockPos pos) {
      if (pos.getY() >= 0 && pos.getY() < 256) {
         int i = pos.getX().shiftRight(4).subtract(this.chunkX).intValueExact();
         int j = pos.getZ().shiftRight(4).subtract(this.chunkZ).intValueExact();
         return this.chunkArray[i][j].getLightFor(type, pos);
      } else {
         return type.defaultLightValue;
      }
   }

   public int getStrongPower(BlockPos pos, EnumFacing direction) {
      return this.getBlockState(pos).getStrongPower(this, pos, direction);
   }

   public WorldType getWorldType() {
      return this.world.getWorldType();
   }
}
