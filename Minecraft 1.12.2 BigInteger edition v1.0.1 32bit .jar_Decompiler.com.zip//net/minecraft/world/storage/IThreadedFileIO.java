package net.minecraft.world.storage;

public interface IThreadedFileIO {
   boolean writeNextIO();
}
