package net.minecraft.world.storage.loot.conditions;

import javax.annotation.ParametersAreNonnullByDefault;
import mcp.MethodsReturnNonnullByDefault;

// $FF: synthetic class
@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
interface package-info {
}
