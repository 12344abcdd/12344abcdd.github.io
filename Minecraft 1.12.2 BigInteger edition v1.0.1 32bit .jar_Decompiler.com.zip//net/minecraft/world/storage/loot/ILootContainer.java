package net.minecraft.world.storage.loot;

import net.minecraft.util.ResourceLocation;

public interface ILootContainer {
   ResourceLocation getLootTable();
}
