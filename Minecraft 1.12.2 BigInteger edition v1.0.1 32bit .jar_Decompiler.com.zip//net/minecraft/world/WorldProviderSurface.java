package net.minecraft.world;

import java.math.BigInteger;

public class WorldProviderSurface extends WorldProvider {
   public DimensionType getDimensionType() {
      return DimensionType.OVERWORLD;
   }

   public boolean canDropChunk(BigInteger x, BigInteger z) {
      return !this.world.isSpawnChunk(x, z);
   }
}
