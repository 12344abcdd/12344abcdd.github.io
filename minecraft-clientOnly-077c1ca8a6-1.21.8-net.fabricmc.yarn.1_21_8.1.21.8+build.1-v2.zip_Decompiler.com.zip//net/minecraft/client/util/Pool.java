package net.minecraft.client.util;

import com.google.common.annotations.VisibleForTesting;
import java.util.ArrayDeque;
import java.util.Collection;
import java.util.Deque;
import java.util.Iterator;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class Pool implements ObjectAllocator, AutoCloseable {
   private final int lifespan;
   private final Deque<Pool.Entry<?>> entries = new ArrayDeque();

   public Pool(int lifespan) {
      this.lifespan = lifespan;
   }

   public void decrementLifespan() {
      Iterator iterator = this.entries.iterator();

      while(iterator.hasNext()) {
         Pool.Entry<?> entry = (Pool.Entry)iterator.next();
         if (entry.lifespan-- == 0) {
            entry.close();
            iterator.remove();
         }
      }

   }

   public <T> T acquire(ClosableFactory<T> factory) {
      T object = this.acquireUnprepared(factory);
      factory.prepare(object);
      return object;
   }

   private <T> T acquireUnprepared(ClosableFactory<T> factory) {
      Iterator iterator = this.entries.iterator();

      Pool.Entry entry;
      do {
         if (!iterator.hasNext()) {
            return factory.create();
         }

         entry = (Pool.Entry)iterator.next();
      } while(!factory.equals(entry.factory));

      iterator.remove();
      return entry.object;
   }

   public <T> void release(ClosableFactory<T> factory, T value) {
      this.entries.addFirst(new Pool.Entry(factory, value, this.lifespan));
   }

   public void clear() {
      this.entries.forEach(Pool.Entry::close);
      this.entries.clear();
   }

   public void close() {
      this.clear();
   }

   @VisibleForTesting
   protected Collection<Pool.Entry<?>> getEntries() {
      return this.entries;
   }

   @Environment(EnvType.CLIENT)
   @VisibleForTesting
   protected static final class Entry<T> implements AutoCloseable {
      final ClosableFactory<T> factory;
      final T object;
      int lifespan;

      Entry(ClosableFactory<T> factory, T object, int lifespan) {
         this.factory = factory;
         this.object = object;
         this.lifespan = lifespan;
      }

      public void close() {
         this.factory.close(this.object);
      }
   }
}
