package net.minecraft.client.render.debug;

import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.network.packet.s2c.custom.DebugGoalSelectorCustomPayload.Goal;
import net.minecraft.util.math.BlockPos;

@Environment(EnvType.CLIENT)
public class GoalSelectorDebugRenderer implements DebugRenderer.Renderer {
   private static final int RANGE = 160;
   private final MinecraftClient client;
   private final Int2ObjectMap<GoalSelectorDebugRenderer.Entity> goalSelectors = new Int2ObjectOpenHashMap();

   public void clear() {
      this.goalSelectors.clear();
   }

   public void setGoalSelectorList(int index, BlockPos pos, List<Goal> goals) {
      this.goalSelectors.put(index, new GoalSelectorDebugRenderer.Entity(pos, goals));
   }

   public void removeGoalSelectorList(int index) {
      this.goalSelectors.remove(index);
   }

   public GoalSelectorDebugRenderer(MinecraftClient client) {
      this.client = client;
   }

   public void render(MatrixStack matrices, VertexConsumerProvider vertexConsumers, double cameraX, double cameraY, double cameraZ) {
      Camera camera = this.client.gameRenderer.getCamera();
      BlockPos blockPos = BlockPos.ofFloored(camera.getPos().x, 0.0D, camera.getPos().z);
      ObjectIterator var11 = this.goalSelectors.values().iterator();

      while(true) {
         GoalSelectorDebugRenderer.Entity entity;
         BlockPos blockPos2;
         do {
            if (!var11.hasNext()) {
               return;
            }

            entity = (GoalSelectorDebugRenderer.Entity)var11.next();
            blockPos2 = entity.entityPos;
         } while(!blockPos.isWithinDistance(blockPos2, 160.0D));

         for(int i = 0; i < entity.goals.size(); ++i) {
            Goal goal = (Goal)entity.goals.get(i);
            double d = (double)blockPos2.getX() + 0.5D;
            double e = (double)blockPos2.getY() + 2.0D + (double)i * 0.25D;
            double f = (double)blockPos2.getZ() + 0.5D;
            int j = goal.isRunning() ? -16711936 : -3355444;
            DebugRenderer.drawString(matrices, vertexConsumers, goal.name(), d, e, f, j);
         }
      }
   }

   @Environment(EnvType.CLIENT)
   private static record Entity(BlockPos entityPos, List<Goal> goals) {
      final BlockPos entityPos;
      final List<Goal> goals;

      Entity(BlockPos blockPos, List<Goal> list) {
         this.entityPos = blockPos;
         this.goals = list;
      }

      public BlockPos entityPos() {
         return this.entityPos;
      }

      public List<Goal> goals() {
         return this.goals;
      }
   }
}
