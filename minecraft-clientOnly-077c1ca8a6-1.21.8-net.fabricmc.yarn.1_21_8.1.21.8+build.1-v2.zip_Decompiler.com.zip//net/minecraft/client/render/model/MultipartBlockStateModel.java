package net.minecraft.client.render.model;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableList.Builder;
import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.ints.IntList;
import java.util.BitSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Predicate;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.BlockState;
import net.minecraft.client.texture.Sprite;
import net.minecraft.util.math.random.Random;
import org.jetbrains.annotations.Nullable;

@Environment(EnvType.CLIENT)
public class MultipartBlockStateModel implements BlockStateModel {
   private final MultipartBlockStateModel.MultipartBakedModel bakedModels;
   private final BlockState state;
   @Nullable
   private List<BlockStateModel> models;

   MultipartBlockStateModel(MultipartBlockStateModel.MultipartBakedModel bakedModels, BlockState state) {
      this.bakedModels = bakedModels;
      this.state = state;
   }

   public Sprite particleSprite() {
      return this.bakedModels.particleSprite;
   }

   public void addParts(Random random, List<BlockModelPart> parts) {
      if (this.models == null) {
         this.models = this.bakedModels.build(this.state);
      }

      long l = random.nextLong();
      Iterator var5 = this.models.iterator();

      while(var5.hasNext()) {
         BlockStateModel blockStateModel = (BlockStateModel)var5.next();
         random.setSeed(l);
         blockStateModel.addParts(random, parts);
      }

   }

   @Environment(EnvType.CLIENT)
   private static final class MultipartBakedModel {
      private final List<MultipartBlockStateModel.Selector<BlockStateModel>> selectors;
      final Sprite particleSprite;
      private final Map<BitSet, List<BlockStateModel>> map = new ConcurrentHashMap();

      private static BlockStateModel getFirst(List<MultipartBlockStateModel.Selector<BlockStateModel>> selectors) {
         if (selectors.isEmpty()) {
            throw new IllegalArgumentException("Model must have at least one selector");
         } else {
            return (BlockStateModel)((MultipartBlockStateModel.Selector)selectors.getFirst()).model();
         }
      }

      public MultipartBakedModel(List<MultipartBlockStateModel.Selector<BlockStateModel>> selectors) {
         this.selectors = selectors;
         BlockStateModel blockStateModel = getFirst(selectors);
         this.particleSprite = blockStateModel.particleSprite();
      }

      public List<BlockStateModel> build(BlockState state) {
         BitSet bitSet = new BitSet();

         for(int i = 0; i < this.selectors.size(); ++i) {
            if (((MultipartBlockStateModel.Selector)this.selectors.get(i)).condition.test(state)) {
               bitSet.set(i);
            }
         }

         return (List)this.map.computeIfAbsent(bitSet, (bitSetx) -> {
            Builder<BlockStateModel> builder = ImmutableList.builder();

            for(int i = 0; i < this.selectors.size(); ++i) {
               if (bitSetx.get(i)) {
                  builder.add((BlockStateModel)((MultipartBlockStateModel.Selector)this.selectors.get(i)).model);
               }
            }

            return builder.build();
         });
      }
   }

   @Environment(EnvType.CLIENT)
   public static class MultipartUnbaked implements BlockStateModel.UnbakedGrouped {
      final List<MultipartBlockStateModel.Selector<BlockStateModel.Unbaked>> selectors;
      private final Baker.ResolvableCacheKey<MultipartBlockStateModel.MultipartBakedModel> bakerCache = new Baker.ResolvableCacheKey<MultipartBlockStateModel.MultipartBakedModel>() {
         // $FF: synthetic field
         final MultipartBlockStateModel.MultipartUnbaked field_57953;

         {
            this.field_57953 = multipartUnbaked;
         }

         public MultipartBlockStateModel.MultipartBakedModel compute(Baker baker) {
            Builder<MultipartBlockStateModel.Selector<BlockStateModel>> builder = ImmutableList.builderWithExpectedSize(this.field_57953.selectors.size());
            Iterator var3 = this.field_57953.selectors.iterator();

            while(var3.hasNext()) {
               MultipartBlockStateModel.Selector<BlockStateModel.Unbaked> selector = (MultipartBlockStateModel.Selector)var3.next();
               builder.add(selector.build(((BlockStateModel.Unbaked)selector.model).bake(baker)));
            }

            return new MultipartBlockStateModel.MultipartBakedModel(builder.build());
         }

         // $FF: synthetic method
         public Object compute(final Baker baker) {
            return this.compute(baker);
         }
      };

      public MultipartUnbaked(List<MultipartBlockStateModel.Selector<BlockStateModel.Unbaked>> selectors) {
         this.selectors = selectors;
      }

      public Object getEqualityGroup(BlockState state) {
         IntList intList = new IntArrayList();

         for(int i = 0; i < this.selectors.size(); ++i) {
            if (((MultipartBlockStateModel.Selector)this.selectors.get(i)).condition.test(state)) {
               intList.add(i);
            }
         }

         return new EqualityGroup(this, intList);
      }

      public void resolve(ResolvableModel.Resolver resolver) {
         this.selectors.forEach((selector) -> {
            ((BlockStateModel.Unbaked)selector.model).resolve(resolver);
         });
      }

      public BlockStateModel bake(BlockState state, Baker baker) {
         MultipartBlockStateModel.MultipartBakedModel multipartBakedModel = (MultipartBlockStateModel.MultipartBakedModel)baker.compute(this.bakerCache);
         return new MultipartBlockStateModel(multipartBakedModel, state);
      }
   }

   @Environment(EnvType.CLIENT)
   public static record Selector<T>(Predicate<BlockState> condition, T model) {
      final Predicate<BlockState> condition;
      final T model;

      public Selector(Predicate<BlockState> predicate, T object) {
         this.condition = predicate;
         this.model = object;
      }

      public <S> MultipartBlockStateModel.Selector<S> build(S object) {
         return new MultipartBlockStateModel.Selector(this.condition, object);
      }

      public Predicate<BlockState> condition() {
         return this.condition;
      }

      public T model() {
         return this.model;
      }
   }
}
