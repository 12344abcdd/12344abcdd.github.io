package net.minecraft.client.render.model.json;

import com.google.common.collect.Lists;
import com.mojang.serialization.Codec;
import java.util.List;
import java.util.function.Predicate;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.state.State;
import net.minecraft.state.StateManager;
import net.minecraft.util.StringIdentifiable;
import net.minecraft.util.Util;

@Environment(EnvType.CLIENT)
public record MultipartModelCombinedCondition(MultipartModelCombinedCondition.LogicalOperator operation, List<MultipartModelCondition> terms) implements MultipartModelCondition {
   public MultipartModelCombinedCondition(MultipartModelCombinedCondition.LogicalOperator logicalOperator, List<MultipartModelCondition> list) {
      this.operation = logicalOperator;
      this.terms = list;
   }

   public <O, S extends State<O, S>> Predicate<S> instantiate(StateManager<O, S> stateManager) {
      return this.operation.apply(Lists.transform(this.terms, (condition) -> {
         return condition.instantiate(stateManager);
      }));
   }

   public MultipartModelCombinedCondition.LogicalOperator operation() {
      return this.operation;
   }

   public List<MultipartModelCondition> terms() {
      return this.terms;
   }

   @Environment(EnvType.CLIENT)
   public static enum LogicalOperator implements StringIdentifiable {
      AND("AND") {
         public <V> Predicate<V> apply(List<Predicate<V>> conditions) {
            return Util.allOf(conditions);
         }
      },
      OR("OR") {
         public <V> Predicate<V> apply(List<Predicate<V>> conditions) {
            return Util.anyOf(conditions);
         }
      };

      public static final Codec<MultipartModelCombinedCondition.LogicalOperator> CODEC = StringIdentifiable.createCodec(MultipartModelCombinedCondition.LogicalOperator::values);
      private final String name;

      LogicalOperator(final String name) {
         this.name = name;
      }

      public String asString() {
         return this.name;
      }

      public abstract <V> Predicate<V> apply(List<Predicate<V>> conditions);

      // $FF: synthetic method
      private static MultipartModelCombinedCondition.LogicalOperator[] method_36940() {
         return new MultipartModelCombinedCondition.LogicalOperator[]{AND, OR};
      }
   }
}
