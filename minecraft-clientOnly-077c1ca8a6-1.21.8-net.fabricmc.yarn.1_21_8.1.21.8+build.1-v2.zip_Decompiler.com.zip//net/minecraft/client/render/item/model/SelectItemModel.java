package net.minecraft.client.render.item.model;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import it.unimi.dsi.fastutil.objects.Object2ObjectMap;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.item.ItemModelManager;
import net.minecraft.client.render.item.ItemRenderState;
import net.minecraft.client.render.item.property.select.SelectProperties;
import net.minecraft.client.render.item.property.select.SelectProperty;
import net.minecraft.client.render.model.ResolvableModel;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.client.world.DataCache;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemDisplayContext;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.ContextSwapper;
import net.minecraft.util.dynamic.Codecs;
import org.jetbrains.annotations.Nullable;

@Environment(EnvType.CLIENT)
public class SelectItemModel<T> implements ItemModel {
   private final SelectProperty<T> property;
   private final SelectItemModel.ModelSelector<T> selector;

   public SelectItemModel(SelectProperty<T> property, SelectItemModel.ModelSelector<T> selector) {
      this.property = property;
      this.selector = selector;
   }

   public void update(ItemRenderState state, ItemStack stack, ItemModelManager resolver, ItemDisplayContext displayContext, @Nullable ClientWorld world, @Nullable LivingEntity user, int seed) {
      state.addModelKey(this);
      T object = this.property.getValue(stack, world, user, seed, displayContext);
      ItemModel itemModel = this.selector.get(object, world);
      if (itemModel != null) {
         itemModel.update(state, stack, resolver, displayContext, world, user, seed);
      }

   }

   @FunctionalInterface
   @Environment(EnvType.CLIENT)
   public interface ModelSelector<T> {
      @Nullable
      ItemModel get(@Nullable T propertyValue, @Nullable ClientWorld world);
   }

   @Environment(EnvType.CLIENT)
   public static record SwitchCase<T>(List<T> values, ItemModel.Unbaked model) {
      final List<T> values;
      final ItemModel.Unbaked model;

      public SwitchCase(List<T> list, ItemModel.Unbaked unbaked) {
         this.values = list;
         this.model = unbaked;
      }

      public static <T> Codec<SelectItemModel.SwitchCase<T>> createCodec(Codec<T> conditionCodec) {
         return RecordCodecBuilder.create((instance) -> {
            return instance.group(Codecs.nonEmptyList(Codecs.listOrSingle(conditionCodec)).fieldOf("when").forGetter(SelectItemModel.SwitchCase::values), ItemModelTypes.CODEC.fieldOf("model").forGetter(SelectItemModel.SwitchCase::model)).apply(instance, SelectItemModel.SwitchCase::new);
         });
      }

      public List<T> values() {
         return this.values;
      }

      public ItemModel.Unbaked model() {
         return this.model;
      }
   }

   @Environment(EnvType.CLIENT)
   public static record UnbakedSwitch<P extends SelectProperty<T>, T>(P property, List<SelectItemModel.SwitchCase<T>> cases) {
      public static final MapCodec<SelectItemModel.UnbakedSwitch<?, ?>> CODEC;

      public UnbakedSwitch(P selectProperty, List<SelectItemModel.SwitchCase<T>> list) {
         this.property = selectProperty;
         this.cases = list;
      }

      public ItemModel bake(ItemModel.BakeContext context, ItemModel fallback) {
         Object2ObjectMap<T, ItemModel> object2ObjectMap = new Object2ObjectOpenHashMap();
         Iterator var4 = this.cases.iterator();

         while(var4.hasNext()) {
            SelectItemModel.SwitchCase<T> switchCase = (SelectItemModel.SwitchCase)var4.next();
            ItemModel.Unbaked unbaked = switchCase.model;
            ItemModel itemModel = unbaked.bake(context);
            Iterator var8 = switchCase.values.iterator();

            while(var8.hasNext()) {
               T object = var8.next();
               object2ObjectMap.put(object, itemModel);
            }
         }

         object2ObjectMap.defaultReturnValue(fallback);
         return new SelectItemModel(this.property, this.buildModelSelector(object2ObjectMap, context.contextSwapper()));
      }

      private SelectItemModel.ModelSelector<T> buildModelSelector(Object2ObjectMap<T, ItemModel> models, @Nullable ContextSwapper contextSwapper) {
         if (contextSwapper == null) {
            return (value, world) -> {
               return (ItemModel)models.get(value);
            };
         } else {
            ItemModel itemModel = (ItemModel)models.defaultReturnValue();
            DataCache<ClientWorld, Object2ObjectMap<T, ItemModel>> dataCache = new DataCache((world) -> {
               Object2ObjectMap<T, ItemModel> object2ObjectMap2 = new Object2ObjectOpenHashMap(models.size());
               object2ObjectMap2.defaultReturnValue(itemModel);
               models.forEach((value, worldx) -> {
                  contextSwapper.swapContext(this.property.valueCodec(), value, world.getRegistryManager()).ifSuccess((swappedValue) -> {
                     object2ObjectMap2.put(swappedValue, worldx);
                  });
               });
               return object2ObjectMap2;
            });
            return (value, world) -> {
               if (world == null) {
                  return (ItemModel)models.get(value);
               } else {
                  return value == null ? itemModel : (ItemModel)((Object2ObjectMap)dataCache.compute(world)).get(value);
               }
            };
         }
      }

      public void resolveCases(ResolvableModel.Resolver resolver) {
         Iterator var2 = this.cases.iterator();

         while(var2.hasNext()) {
            SelectItemModel.SwitchCase<?> switchCase = (SelectItemModel.SwitchCase)var2.next();
            switchCase.model.resolve(resolver);
         }

      }

      public P property() {
         return this.property;
      }

      public List<SelectItemModel.SwitchCase<T>> cases() {
         return this.cases;
      }

      static {
         CODEC = SelectProperties.CODEC.dispatchMap("property", (unbakedSwitch) -> {
            return unbakedSwitch.property().getType();
         }, SelectProperty.Type::switchCodec);
      }
   }

   @Environment(EnvType.CLIENT)
   public static record Unbaked(SelectItemModel.UnbakedSwitch<?, ?> unbakedSwitch, Optional<ItemModel.Unbaked> fallback) implements ItemModel.Unbaked {
      public static final MapCodec<SelectItemModel.Unbaked> CODEC = RecordCodecBuilder.mapCodec((instance) -> {
         return instance.group(SelectItemModel.UnbakedSwitch.CODEC.forGetter(SelectItemModel.Unbaked::unbakedSwitch), ItemModelTypes.CODEC.optionalFieldOf("fallback").forGetter(SelectItemModel.Unbaked::fallback)).apply(instance, SelectItemModel.Unbaked::new);
      });

      public Unbaked(SelectItemModel.UnbakedSwitch<?, ?> unbakedSwitch, Optional<ItemModel.Unbaked> optional) {
         this.unbakedSwitch = unbakedSwitch;
         this.fallback = optional;
      }

      public MapCodec<SelectItemModel.Unbaked> getCodec() {
         return CODEC;
      }

      public ItemModel bake(ItemModel.BakeContext context) {
         ItemModel itemModel = (ItemModel)this.fallback.map((model) -> {
            return model.bake(context);
         }).orElse(context.missingItemModel());
         return this.unbakedSwitch.bake(context, itemModel);
      }

      public void resolve(ResolvableModel.Resolver resolver) {
         this.unbakedSwitch.resolveCases(resolver);
         this.fallback.ifPresent((model) -> {
            model.resolve(resolver);
         });
      }

      public SelectItemModel.UnbakedSwitch<?, ?> unbakedSwitch() {
         return this.unbakedSwitch;
      }

      public Optional<ItemModel.Unbaked> fallback() {
         return this.fallback;
      }
   }
}
