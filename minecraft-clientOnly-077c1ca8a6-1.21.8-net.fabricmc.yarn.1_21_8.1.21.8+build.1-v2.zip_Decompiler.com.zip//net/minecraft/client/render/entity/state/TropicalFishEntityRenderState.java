package net.minecraft.client.render.entity.state;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.passive.TropicalFishEntity.Pattern;

@Environment(EnvType.CLIENT)
public class TropicalFishEntityRenderState extends LivingEntityRenderState {
   public Pattern variety;
   public int baseColor;
   public int patternColor;

   public TropicalFishEntityRenderState() {
      this.variety = Pattern.FLOPPER;
      this.baseColor = -1;
      this.patternColor = -1;
   }
}
