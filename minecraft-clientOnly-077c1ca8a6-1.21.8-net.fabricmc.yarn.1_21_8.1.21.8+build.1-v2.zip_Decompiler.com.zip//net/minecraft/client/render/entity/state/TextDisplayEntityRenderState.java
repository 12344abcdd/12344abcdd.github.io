package net.minecraft.client.render.entity.state;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.decoration.DisplayEntity.TextDisplayEntity.Data;
import net.minecraft.entity.decoration.DisplayEntity.TextDisplayEntity.TextLines;
import org.jetbrains.annotations.Nullable;

@Environment(EnvType.CLIENT)
public class TextDisplayEntityRenderState extends DisplayEntityRenderState {
   @Nullable
   public Data data;
   @Nullable
   public TextLines textLines;

   public boolean canRender() {
      return this.data != null;
   }
}
