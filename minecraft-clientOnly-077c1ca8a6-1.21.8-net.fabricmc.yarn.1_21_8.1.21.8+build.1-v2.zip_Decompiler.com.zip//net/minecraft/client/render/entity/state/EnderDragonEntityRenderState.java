package net.minecraft.client.render.entity.state;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.boss.dragon.EnderDragonFrameTracker;
import net.minecraft.entity.boss.dragon.EnderDragonFrameTracker.Frame;
import net.minecraft.util.math.Vec3d;
import org.jetbrains.annotations.Nullable;

@Environment(EnvType.CLIENT)
public class EnderDragonEntityRenderState extends EntityRenderState {
   public float wingPosition;
   public float ticksSinceDeath;
   public boolean hurt;
   @Nullable
   public Vec3d crystalBeamPos;
   public boolean inLandingOrTakeoffPhase;
   public boolean sittingOrHovering;
   public double squaredDistanceFromOrigin;
   public float tickProgress;
   public final EnderDragonFrameTracker frameTracker = new EnderDragonFrameTracker();

   public Frame getLerpedFrame(int age) {
      return this.frameTracker.getLerpedFrame(age, this.tickProgress);
   }

   public float getNeckPartPitchOffset(int id, Frame bodyFrame, Frame neckFrame) {
      double d;
      if (this.inLandingOrTakeoffPhase) {
         d = (double)id / Math.max(this.squaredDistanceFromOrigin / 4.0D, 1.0D);
      } else if (this.sittingOrHovering) {
         d = (double)id;
      } else if (id == 6) {
         d = 0.0D;
      } else {
         d = neckFrame.y() - bodyFrame.y();
      }

      return (float)d;
   }
}
