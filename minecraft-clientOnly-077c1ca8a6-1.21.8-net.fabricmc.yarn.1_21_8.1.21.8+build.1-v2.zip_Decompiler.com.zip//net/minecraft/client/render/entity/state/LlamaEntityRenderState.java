package net.minecraft.client.render.entity.state;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.passive.LlamaEntity.Variant;
import net.minecraft.item.ItemStack;

@Environment(EnvType.CLIENT)
public class LlamaEntityRenderState extends LivingEntityRenderState {
   public Variant variant;
   public boolean hasChest;
   public ItemStack bodyArmor;
   public boolean trader;

   public LlamaEntityRenderState() {
      this.variant = Variant.DEFAULT;
      this.bodyArmor = ItemStack.EMPTY;
   }
}
